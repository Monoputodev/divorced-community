<?php $__env->startSection('content'); ?>
    <div class="login section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-xl-6">
                    <div class="login__wrapper">
                        <form action="<?php echo e(route('user.data.submit', 'physicalAttributeInfo')); ?>" autocomplete="off" class="info-form" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="section__head text-center">
                                <h2 class="mt-0 login-title"><?php echo e(__($pageTitle)); ?></h2>
                            </div>
                            <div class="row gy-4">
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="complexion" required type="text" value="<?php echo e(old('complexion')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Complexion'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <input class="form-control form--control" min="0" name="height" required step="any" type="number" value="<?php echo e(old('height')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Height'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <input class="form-control form--control" min="0" name="weight" required step="any" type="number" value="<?php echo e(old('weight')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Weight'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="blood_group" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <?php $__currentLoopData = $bloodGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($blood->name); ?>"><?php echo e(__($blood->name)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Blood Group'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="eye_color" required type="text" value="<?php echo e(old('eye_color')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Eye Color'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="hair_color" required type="text" value="<?php echo e(old('hair_color')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Hair Color'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="disability" type="text" value="<?php echo e(old('disability')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Disability'); ?></label>
                                    </div>
                                </div>
                                <div class="append-form d-none"></div>
                                <div class="d-flex justify-content-end flex-wrap gap-2">
                                    <button class="btn btn-sm btn--dark back-btn" type="button"><i class="las la-arrow-left"></i><?php echo app('translator')->get('Back'); ?></button>
                                    <button class="btn btn-sm btn--warning skip-btn" type="button"><i class="las la-forward"></i> <?php echo app('translator')->get('Skip'); ?></button>
                                    <button class="btn btn-sm btn-success" name="button_value" type="submit" value="submit"><?php echo app('translator')->get('Next'); ?> <i class="las la-arrow-right"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";

        $('.skip-btn').on('click', function() {
            $('.info-form').submit();
        })

        $('.back-btn').on('click', function() {
            $('.append-form').append(`<input type="hidden" name="back_to" value="careerInfo">`);
            $('.info-form').submit();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/information/physical_attributes.blade.php ENDPATH**/ ?>