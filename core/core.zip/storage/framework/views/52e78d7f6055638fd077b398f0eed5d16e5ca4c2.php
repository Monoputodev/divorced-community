 <!-- Physical Attributes -->
 <div class="public-profile__accordion accordion custom--accordion" id="accordionPanelsStayOpenExample">
     <div class="accordion-item">
         <h2 class="accordion-header" id="panelsStayOpen-physicalAttr">
             <button class="accordion-button collapsed" data-bs-target="#panelsStayOpen-collapsePhysicalAttr" data-bs-toggle="collapse" type="button" aria-expanded="false" aria-controls="panelsStayOpen-collapsePhysicalAttr">
                 <?php echo app('translator')->get('Physical Attributes'); ?>
             </button>
         </h2>
         <div class="accordion-collapse collapse" id="panelsStayOpen-collapsePhysicalAttr" aria-labelledby="panelsStayOpen-physicalAttr">
             <div class="accordion-body">
                 <form class="physical-attr-form" action="" autocomplete="off" method="POST">
                     <?php echo csrf_field(); ?>

                     <input name="method" type="hidden" value="physicalAttributes">
                     <div class="row gy-4">
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <input class="form-control form--control" name="complexion" type="text" value="<?php echo e(@$user->physicalAttributes->complexion); ?>" required>
                                 <label class="form--label"><?php echo app('translator')->get('Complexion'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <input class="form-control form--control" name="height" type="number" value="<?php echo e(@$user->physicalAttributes->height); ?>" min="0" required step="any">
                                 <label class="form--label"><?php echo app('translator')->get('Height'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <input class="form-control form--control" name="weight" type="number" value="<?php echo e(@$user->physicalAttributes->weight); ?>" min="0" required step="any">
                                 <label class="form--label"><?php echo app('translator')->get('Weight'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <select class="form-select form-control form--control" name="blood_group">
                                     <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                     <?php $__currentLoopData = $bloodGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($blood->name); ?>"><?php echo e(__($blood->name)); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                                 <label class="form--label"><?php echo app('translator')->get('Blood Group'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <input class="form-control form--control" name="eye_color" type="text" value="<?php echo e(@$user->physicalAttributes->eye_color); ?>" required>
                                 <label class="form--label"><?php echo app('translator')->get('Eye Color'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <input class="form-control form--control" name="hair_color" type="text" value="<?php echo e(@$user->physicalAttributes->hair_color); ?>" required>
                                 <label class="form--label"><?php echo app('translator')->get('Hair Color'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <input class="form-control form--control" name="disability" type="text" value="<?php echo e(@$user->physicalAttributes->disability); ?>">
                                 <label class="form--label"><?php echo app('translator')->get('Disability'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <button class="btn btn--base w-100 mt-0" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                         </div>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </div>
 <!-- Physical Attributes end-->

 <?php $__env->startPush('script'); ?>
     <script>
         "use strict";
         let physicalAttrForm = $('.physical-attr-form');
         let bloodGroup = "<?php echo e(@$user->physicalAttributes->blood_group); ?>";

         physicalAttrForm.find('[name=blood_group]').val(bloodGroup);
     </script>
 <?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/profile_setting/physical_attributes.blade.php ENDPATH**/ ?>