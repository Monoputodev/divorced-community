<div class="col-md-6">
    <div class="search__right-details">
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Age'); ?></span>
            </label>
            <span class="col-7">
                <?php
                    $age = now()->diffInYears(@$member->basicInfo->birth_date);
                ?>
                <?php echo e($age ? $age . ' ' . __('Years') : __('N/A')); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Blood Group'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->physicalAttributes->blood_group) ?? __('N/A')); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Height'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(@$member->physicalAttributes->height ? __(@$member->physicalAttributes->height) . ' Ft.' : 'N/A'); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Religion'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->basicInfo->religion ?? 'N/A')); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Languages'); ?></span>
            </label>
            <span class="col-7">
                <?php if(@$member->basicInfo): ?>
                    <?php if(count($member->basicInfo->language)): ?>
                        <?php echo e(implode(', ', $member->basicInfo->language)); ?>

                    <?php else: ?>
                        <?php echo app('translator')->get('N/A'); ?>
                    <?php endif; ?>
                <?php else: ?>
                    <?php echo app('translator')->get('N/A'); ?>
                <?php endif; ?>
            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Eye Color'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->physicalAttributes->eye_color ?? 'N/A')); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Hair Color'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->physicalAttributes->hair_color ?? 'N/A')); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Disability'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->physicalAttributes->disability ?? 'N/A')); ?>

            </span>
        </div>
    </div>
</div>
<div class="col-md-6">
    <div class="search__right-details">
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Profession'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->basicInfo->profession ?? 'N/A')); ?></span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Complexion'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->physicalAttributes->complexion ?? 'N/A')); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Present Address'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->basicInfo->present_address->city)); ?>

                <?php if(@$member->basicInfo->present_address->city): ?>
                    ,
                <?php endif; ?>
                <?php echo e(__(@$member->basicInfo->present_address->country)); ?>

            </span>
        </div>
        <div class="row member-details">
            <label class="col-5">
                <span><?php echo app('translator')->get('Permanent Address'); ?></span>
            </label>
            <span class="col-7">
                <?php if(@$member->basicInfo->permanent_address): ?>
                    <?php echo e(__(@$member->basicInfo->permanent_address->city)); ?>

                    <?php if(@$member->basicInfo->permanent_address->city): ?>
                        ,
                    <?php endif; ?>
                    <?php echo e(__(@$member->basicInfo->permanent_address->country)); ?>

                <?php else: ?>
                    <?php echo app('translator')->get('N/A'); ?>
                <?php endif; ?>
            </span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Father\'s Name'); ?></span>
            </label>
            <span
                class="col-7"><?php echo e(__(@$member->family->father_name ?? 'N/A')); ?></span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Father\'s Profession'); ?></span>
            </label>
            <span
                class="col-7"><?php echo e(__(@$member->family->father_profession ?? 'N/A')); ?></span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Mother\'s Name'); ?></span>
            </label>
            <span class="col-7">
                <?php echo e(__(@$member->family->mother_name ?? 'N/A')); ?></span>
        </div>
        <div class="row member-details">
            <label class="col-5"><span><?php echo app('translator')->get('Mother\'s Profession'); ?></span>
            </label>
            <span
                class="col-7"><?php echo e(__(@$member->family->mother_profession ?? 'N/A')); ?></span>
        </div>
    </div>
</div>
<?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/members/basic_info.blade.php ENDPATH**/ ?>