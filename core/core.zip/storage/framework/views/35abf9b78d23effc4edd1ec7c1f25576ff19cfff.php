<?php
    $activeMembers = \App\Models\User::active();
    $Members = (clone $activeMembers)
        ->orderBy('id', 'ASC')
        ->take(4)
        ->get();
        dd($Members);
    $totalMember = $activeMembers->count();
?>
<?php echo $__env->make($activeTemplate . 'partials.Member', ['Members' => $Members, 'totalMember' => $totalMember], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/sections/members.blade.php ENDPATH**/ ?>