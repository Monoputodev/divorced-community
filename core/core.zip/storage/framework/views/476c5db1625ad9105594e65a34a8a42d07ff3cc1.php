<?php $__env->startSection('content'); ?>
    <div class="login section partner-expectation">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-xl-6">
                    <div class="login__wrapper">
                        <form class="info-form" action="<?php echo e(route('user.data.submit', 'partnerExpectation')); ?>" autocomplete="off" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="section__head text-center">
                                <h2 class="login-title mt-0"><?php echo e(__($pageTitle)); ?></h2>
                            </div>
                            <div class="row gy-4">
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <textarea class="form-control form--control" name="general_requirement" value="<?php echo e(old('general_requirement')); ?>"></textarea>
                                        <label class="form--label"><?php echo app('translator')->get('General Requirement'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <div class="input--group">
                                            <select name="country"class="form-select form-control form--control">
                                                <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->country); ?>"><?php echo e(__($country->country)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label class="form--label"><?php echo app('translator')->get('Country'); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="min_age" type="number" value="<?php echo e(old('min_age')); ?>" min="0" step="any">
                                        <label class="form--label"><?php echo app('translator')->get('Minimum Age'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="max_age" type="number" value="<?php echo e(old('max_age')); ?>" min="0" step="any">
                                        <label class="form--label"><?php echo app('translator')->get('Maximum Age'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="min_height" type="number" value="<?php echo e(old('min_height')); ?>" min="0" step="any">
                                        <label class="form--label"><?php echo app('translator')->get('Minimum Height'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="max_height" type="number" value="<?php echo e(old('max_height')); ?>" min="0" step="any">
                                        <label class="form--label"><?php echo app('translator')->get('Maximum Height'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="max_weight" type="number" value="<?php echo e(old('max_weight')); ?>" min="0" step="any">
                                        <label class="form--label"><?php echo app('translator')->get('Maximum Weight'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="marital_status">
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maritalStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($maritalStatus->title); ?>" <?php if(old('marital_status' == $maritalStatus->title)): echo 'selected'; endif; ?>><?php echo e(__($maritalStatus->title)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Marital Status'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="religion">
                                            <option value=""><?php echo app('translator')->get('Religion'); ?></option>
                                            <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($religion->name); ?>" <?php if(old('religion' == $religion->name)): echo 'selected'; endif; ?>><?php echo e(__($religion->name)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="complexion" type="text" value="<?php echo e(old('complexion')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Complexion'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="smoking_status">
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <option value="1" <?php if(old('smoking_status' == 1)): echo 'selected'; endif; ?>><?php echo app('translator')->get('Smoker'); ?></option>
                                            <option value="2" <?php if(old('smoking_status' == 2)): echo 'selected'; endif; ?>><?php echo app('translator')->get('Non-smoker'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Smoking Habits'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="drinking_status">
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <option value="1" <?php if(old('drinking_status' == 1)): echo 'selected'; endif; ?>><?php echo app('translator')->get('Drunker'); ?></option>
                                            <option value="2" <?php if(old('drinking_status' == 2)): echo 'selected'; endif; ?>><?php echo app('translator')->get('Restrianed'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Drinking Status'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="min_degree" type="text" value="<?php echo e(old('min_degree')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Minimum Degree'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="profession" type="text" value="<?php echo e(old('profession')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Profession'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-control form--control select2-auto-tokenize" name="language[]" multiple="multiple">
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Languages'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="personality" type="text" value="<?php echo e(old('personality')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Personality'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="financial_condition" type="text" value="<?php echo e(old('financial_condition')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Financial Condition'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="family_position" type="text" value="<?php echo e(old('family_position')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Family Position'); ?></label>
                                    </div>
                                </div>
                                <div class="append-form d-none"></div>
                                <div class="d-flex justify-content-end flex-wrap gap-2">
                                    <button class="btn btn-sm btn--dark back-btn" type="button"><i class="las la-arrow-left"></i><?php echo app('translator')->get('Back'); ?></button>
                                    <button class="btn btn-sm btn--warning skip-btn" type="button"><i class="las la-forward"></i> <?php echo app('translator')->get('Skip'); ?></button>
                                    <button class="btn btn-sm btn-success" name="button_value" type="submit" value="submit"><?php echo app('translator')->get('Next'); ?> <i class="las la-arrow-right"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset('assets/admin/css/vendor/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/vendor/select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";

        if (!$('.datepicker-here').val()) {
            $('.datepicker-here').datepicker({
                autoClose: true,
            });
        }

        $('.skip-btn').on('click', function() {
            $('.info-form').submit();
        });

        $('.select2-auto-tokenize').select2({
            dropdownParent: $('.partner-expectation'),
            tags: true,
            tokenSeparators: [',']
        });

        $('.back-btn').on('click', function() {
            $('.append-form').append(`<input type="hidden" name="back_to" value="physicalAttributeInfo">`);
            $('.info-form').submit();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/information/partner_expectation.blade.php ENDPATH**/ ?>