<?php
    $content = getContent('email_verify.content', true);
?>

<?php $__env->startSection('content'); ?>
    <div class="login section">
        <div class="container">
            <div class="row gy-5 justify-content-center">
                <div class="col-md-6">
                    <div class="d-flex justify-content-center">
                        <div class="verification-code-wrapper login__wrapper">
                            <div class="verification-area">
                                <div class="section__head pb-3 text-center">
                                    <h2 class="login-title mt-0"><?php echo e(__(@$content->data_values->heading)); ?></h2>
                                    <p class="t-short-para mx-auto mb-0 text-center">
                                        <?php echo e(__(@$content->data_values->subheading)); ?>:
                                        <?php echo e(showEmailAddress(auth()->user()->email)); ?>

                                    </p>
                                </div>
                                <form class="submit-form" action="<?php echo e(route('user.verify.email')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo $__env->make($activeTemplate . 'partials.verification_code', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <button class="btn btn--base w-100 mt-3" type="submit"><?php echo app('translator')->get('Submit'); ?></button>

                                    <div class="input--group email-verify mt-3">
                                        <?php echo app('translator')->get('If you don\'t get any code'); ?>,
                                        <a href="<?php echo e(route('user.send.verify.code', 'email')); ?>"> <?php echo app('translator')->get('Try again'); ?></a>
                                        <?php if($errors->has('resend')): ?>
                                            <small class="text-danger d-block"><?php echo e($errors->first('resend')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/auth/authorization/email.blade.php ENDPATH**/ ?>