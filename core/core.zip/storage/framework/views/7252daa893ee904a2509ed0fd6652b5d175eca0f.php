<?php
    $user = auth()->user();
    $lang = App\Models\LangInfo::all();
?>

<?php $__env->startSection('content'); ?>
    <div class="login section basic-info">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="login__wrapper basic-information">
                        <form class="info-form" action="<?php echo e(route('user.data.submit', 'basicInfo')); ?>" autocomplete="off" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="section__head text-center">
                                <h2 class="login-title mt-0"><?php echo app('translator')->get('Basic Information'); ?></h2>
                                <p><?php echo app('translator')->get('Fill up your basic information with authenticated data, you also can skip this step by clicking skip button'); ?></p>
                            </div>
                            <div class="row gy-4">
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="datepicker-here form-control form--control" name="birth_date" data-date-format="yyyy-mm-dd" data-language="en" data-position='bottom right' data-range="false" type="text" value="<?php echo e(old('birth_date')); ?>" autocomplete="off" required>
                                        <label class="form--label"><?php echo app('translator')->get('Date Of Birth'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="religion" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($religion->name); ?>" <?php if(old('religion') == $religion->name): ?> selected <?php endif; ?>>
                                                    <?php echo e(__($religion->name)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Religion'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="gender" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <option value="m" <?php if(old('gender') == 'm'): ?> selected <?php endif; ?>>
                                                <?php echo app('translator')->get('Male'); ?></option>
                                            <option value="f" <?php if(old('gender') == 'f'): ?> selected <?php endif; ?>>
                                                <?php echo app('translator')->get('Female'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Gender'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="marital_status" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maritalStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($maritalStatus->title); ?>" <?php if(old('marital_status') == $maritalStatus->title): ?> selected <?php endif; ?>>
                                                    <?php echo e(__($maritalStatus->title)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Marital Status'); ?></label>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-control form--control select2-auto-tokenize" name="languages[]" multiple="multiple" placeholder="none" required>
                                            <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Language->name); ?>"><?php echo e($Language->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Languages'); ?></label>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="profession" type="text" value="<?php echo e(old('profession')); ?>" required>
                                        <label class="form--label"><?php echo app('translator')->get('Profession'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="financial_condition" type="text" value="<?php echo e(old('financial_condition')); ?>" required>
                                        <label class="form--label"><?php echo app('translator')->get('Financial Condition'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="smoking_status" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <option value="1" <?php if(old('smoking_status') == 1): echo 'selected'; endif; ?>><?php echo app('translator')->get('Smoker'); ?></option>
                                            <option value="0" <?php if(old('smoking_status') == 0): echo 'selected'; endif; ?>><?php echo app('translator')->get('Non-smoker'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Smoking Habits'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="drinking_status" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <option value="1" <?php if(old('drinking_status') == 1): echo 'selected'; endif; ?>><?php echo app('translator')->get('Drunker'); ?></option>
                                            <option value="0" <?php if(old('drinking_status') == 0): echo 'selected'; endif; ?>><?php echo app('translator')->get('Non-drunker'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Drinking Status'); ?></label>
                                    </div>
                                </div>

                                <small><?php echo app('translator')->get('Present Address'); ?></small>

                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="pre_country" <?php if(@$user->address->country): echo 'disabled'; endif; ?>>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->country); ?>" <?php if(old('pre_country', @$user->address->country) == $country->country): ?> selected <?php endif; ?>>
                                                    <?php echo e(__($country->country)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Permanent Country'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="pre_state" type="text" value="<?php echo e(old('pre_state', @$user->address->state)); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('State'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="pre_zip" type="text" value="<?php echo e(old('pre_zip', @$user->address->zip)); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Zip Code'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" name="pre_city" type="text" value="<?php echo e(old('pre_city', @$user->address->city)); ?>" required>
                                        <label class="form--label"><?php echo app('translator')->get('City'); ?></label>
                                    </div>
                                </div>

                                <small>
                                    <div class="form--check">
                                        <?php echo app('translator')->get('Permanent Address'); ?> :
                                        <input class="form-check-input" id="copyAddress" type="checkbox">
                                        <label class="form-check-label" for="copyAddress">
                                            <?php echo app('translator')->get('Same as present address?'); ?>
                                        </label>
                                    </div>
                                </small>

                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" name="per_country" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->country); ?>" <?php if(old('per_country') == $country->country): ?> selected <?php endif; ?>>
                                                    <?php echo e(__($country->country)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Present Country'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control permanent" name="per_state" type="text" value="<?php echo e(old('per_state')); ?>" required>
                                        <label class="form--label"><?php echo app('translator')->get('State'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control permanent" name="per_zip" type="text" value="<?php echo e(old('per_zip')); ?>">
                                        <label class="form--label"><?php echo app('translator')->get('Zip Code'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control permanent" name="per_city" type="text" value="<?php echo e(old('per_city')); ?>" required>
                                        <label class="form--label"><?php echo app('translator')->get('City'); ?></label>
                                    </div>
                                </div>
                                <div class="append-form d-none"></div>
                                <div class="d-flex justify-content-end flex-wrap gap-2">
                                    <button class="btn btn-sm btn--dark skip-all" type="button"><i class="las la-hand-point-right"></i> <?php echo app('translator')->get('Skip All'); ?></button>
                                    <button class="btn btn-sm btn--warning skip-btn" type="button"><i class="las la-forward"></i> <?php echo app('translator')->get('Skip'); ?></button>
                                    <button class="btn btn-sm btn-success" name="button_value" type="submit" value="submit"><?php echo app('translator')->get('Next'); ?> <i class="las la-arrow-right"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset('assets/admin/css/vendor/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/vendor/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/vendor/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/vendor/datepicker.en.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        $('.skip-btn').on('click', function() {
            $('.info-form').submit();
        });

        $('.select2-auto-tokenize').select2({
            dropdownParent: $('.basic-info'),
            tags: true,
            tokenSeparators: [',']
        });

        $('#copyAddress').on('change', function() {
            let perCountry = $('[name=per_country]');
            let perState = $('[name=per_state]');
            let perZip = $('[name=per_zip]');
            let perCity = $('[name=per_city]');
            if ($(this).is(':checked')) {
                perCountry.val($('[name=pre_country]').val());
                perState.val($('[name=pre_state]').val());
                perZip.val($('[name=pre_zip]').val());
                perCity.val($('[name=pre_city]').val());
            } else {
                perCountry.val('');
                perState.val('');
                perZip.val('');
                perCity.val('');
            }
        })

        $('.skip-all').on('click', function() {
            $('.append-form').append(`<input type="hidden" name="skip_all" value="1" >`);
            $('.info-form').submit();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/information/basic.blade.php ENDPATH**/ ?>