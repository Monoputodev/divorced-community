<div class="table-responsive--md">
    <table class="custom--table table">
        <?php if($interests->count()): ?>
            <thead>
                <tr>
                    <th><?php echo app('translator')->get('S.N'); ?></th>
                    <th><?php echo app('translator')->get('Name'); ?></th>
                    <th><?php echo app('translator')->get('Age'); ?></th>
                    <th><?php echo app('translator')->get('Religion'); ?></th>
                    <th><?php echo app('translator')->get('Status'); ?></th>
                    <th><?php echo app('translator')->get('Action'); ?></th>
                </tr>
            </thead>
        <?php endif; ?>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($pagination == true): ?>
                            <?php echo e($interests->firstItem() + $loop->index); ?>

                        <?php else: ?>
                            <?php echo e($loop->index + 1); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-flex align-items-center gap-3">
                            <div class="user user--sm">
                                <img class="user__img" src="<?php echo e(getImage(getFilePath('userProfile') . '/' . @$interest->profile->image, null, 'user')); ?>" alt="<?php echo app('translator')->get('Image'); ?>" />
                            </div>
                            <h6 class="user__text d-inline-block mt-0 mb-0">
                                <a href="<?php echo e(route('user.member.profile.public', $interest->profile->id)); ?>"><?php echo e(__($interest->profile->fullname)); ?></a>
                            </h6>
                        </div>
                    </td>
                    <td><?php echo e(@$interest->profile->basicInfo->birth_date ? now()->diffInYears(@$interest->profile->basicInfo->birth_date) : 'N/A'); ?></td>
                    <td><?php echo e(__(@$interest->profile->basicInfo->religion ?? 'N/A')); ?></td>
                    <td>
                        <?php
                            echo $interest->statusBadge;
                        ?>
                    </td>
                    <td>
                        <?php if($interest->status == Status::ENABLE): ?>
                            <a class="icon-anchor btn--messenger" data-bs-toggle="tooltip" href="<?php echo e(route('user.message.index', encrypt($interest->conversation->id))); ?>" title="<?php echo app('translator')->get('Message'); ?>"><i class="las la-envelope"></i></a>
                        <?php else: ?>
                            <a class="icon-anchor btn--danger" data-bs-toggle="tooltip" href="javascript::void(0)" title="<?php echo app('translator')->get('You can message after accepted the request'); ?>"><i class="las la-envelope"></i></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="100">
                        <div class="empty-table text-center">
                            <div class="empty-table__icon">
                                <i class="las la-frown"></i>
                            </div>
                            <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?></h6>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/partials/interest_table.blade.php ENDPATH**/ ?>