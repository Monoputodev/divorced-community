<div class="d-flex mb-30 flex-wrap gap-3 justify-content-between align-items-center">
    <h6 class="page-title"><?php echo e(__($pageTitle)); ?></h6>
    <div class="d-flex flex-wrap justify-content-end gap-2 align-items-center breadcrumb-plugins">
        <?php echo $__env->yieldPushContent('breadcrumb-plugins'); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/admin/partials/breadcrumb.blade.php ENDPATH**/ ?>