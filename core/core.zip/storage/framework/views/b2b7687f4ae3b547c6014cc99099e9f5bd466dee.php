

<div class="row">
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3">
    <div class="card border-0 rounded-0 shadow-sm">
        <img src="<?php echo e(getImage('assets/images/frontend/blogs/' . $blog->data_values->image)); ?>" class="card-img-top rounded-0" alt="Blog post image">
        <div class="card-body">
          <h5 class="card-title mb-3 text-justify"><?php echo strLimit(trans($blog->data_values->title),40) ?></h5>
          <p class="card-text text-muted text-justify">    <?php echo strLimit(strip_tags($blog->data_values->description),70) ?></p>
          <div class="d-flex justify-content-center">
            <a href="<?php echo e(route('blog.details', [slug($blog->data_values->title), $blog->id])); ?>" class="btn btn--base btn--sm">Read More</a>
          </div>
        </div>
      </div>

</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/partials/blogs_grid.blade.php ENDPATH**/ ?>