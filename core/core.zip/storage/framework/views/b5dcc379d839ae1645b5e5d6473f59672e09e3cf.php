<!-- Education Information -->
<div class="public-profile__accordion accordion custom--accordion" id="accordionPanelsStayOpenExample">
    <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-educationInfo">
            <button class="accordion-button collapsed" data-bs-target="#panelsStayOpen-collapseEducationInfo" data-bs-toggle="collapse" type="button" aria-expanded="false" aria-controls="panelsStayOpen-collapseEducationInfo">
                <?php echo app('translator')->get('Education Information'); ?>
            </button>
        </h2>
        <div class="accordion-collapse collapse" id="panelsStayOpen-collapseEducationInfo" aria-labelledby="panelsStayOpen-educationInfo">
            <div class="accordion-body">
                <div class="row">
                    <div class="col-12 pb-4 text-end">
                        <button class="btn btn-sm btn--base btnAddEducation mt-0" data-action="<?php echo e(route('user.education.update')); ?>" data-title="<?php echo app('translator')->get('Add Education Information'); ?>">
                            <i class="las la-plus"> <?php echo app('translator')->get('Add New'); ?></i>
                        </button>
                    </div>
                    <div class="col-md-12">
                        <div class="table-responsive--md">
                            <table class="custom--table table table">
                                <?php if($user->educationInfo->count()): ?>
                                    <thead>
                                        <tr>
                                            <th><?php echo app('translator')->get('S.N'); ?></th>
                                            <th><?php echo app('translator')->get('Degree'); ?></th>
                                            <th><?php echo app('translator')->get('Institute'); ?></th>
                                            <th><?php echo app('translator')->get('Field'); ?></th>
                                            <th><?php echo app('translator')->get('Result'); ?></th>
                                            <th><?php echo app('translator')->get('Start'); ?></th>
                                            <th><?php echo app('translator')->get('End'); ?></th>
                                            <th><?php echo app('translator')->get('Action'); ?></th>
                                        </tr>
                                    </thead>
                                <?php endif; ?>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $user->educationInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e(__($education->degree)); ?></td>
                                            <td><?php echo e(__($education->institute)); ?></td>
                                            <td><?php echo e(__($education->field_of_study)); ?>

                                            </td>
                                            <td><?php echo e($education->result); ?>

                                            </td>
                                            <td><?php echo e($education->start); ?></td>
                                            <td><?php echo e($education->end ?? __('Running')); ?>

                                            </td>
                                            <td>
                                                <button class="icon-btn btn--info btnEditEducation" data-action="<?php echo e(route('user.education.update', $education->id)); ?>" data-bs-toggle="tooltip" data-education="<?php echo e($education); ?>" data-title="<?php echo app('translator')->get('Update Education Information'); ?>" type="button" title="<?php echo app('translator')->get('Edit'); ?>">
                                                    <i class="la la-edit"></i>
                                                </button>
                                                <button class="icon-btn btn--danger confirmationBtn" data-action="<?php echo e(route('user.education.delete', $education->id)); ?>" data-bs-toggle="tooltip" data-question="<?php echo app('translator')->get('Are your sure, you want to delete this Education Information?'); ?>" title="<?php echo app('translator')->get('Delete'); ?>">
                                                    <i class="las la-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="100">
                                                <div class="empty-table text-center">
                                                    <div class="empty-table__icon">
                                                        <i class="las la-frown"></i>
                                                    </div>
                                                    <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?></h6>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--Career Modal -->
<div class="modal custom--modal fade" id="educationModal" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
            </div>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row gy-4">
                        <div class="col-sm-6">
                            <div class="input--group">
                                <input class="form-control form--control" name="institute" type="text" required>
                                <label class="form--label"><?php echo app('translator')->get('Institute'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input--group">
                                <input class="form-control form--control" name="degree" type="text" required>
                                <label class="form--label"><?php echo app('translator')->get('Degree'); ?></label>
                            </div>
                        </div>

                        <div class="col-sm-6 mt-4">
                            <div class="input--group">
                                <input class="form-control form--control" name="field_of_study" type="text" required>
                                <label class="form--label"><?php echo app('translator')->get('Field Of Study'); ?></label>
                            </div>
                        </div>

                        <div class="col-sm-6 mt-4">
                            <div class="input--group">
                                <input class="form-control form--control" name="reg_no" type="number">
                                <label class="form--label"><?php echo app('translator')->get('Registration No.'); ?></label>
                            </div>
                        </div>

                        <div class="col-sm-6 mt-4">
                            <div class="input--group">
                                <input class="form-control form--control" name="roll_no" type="number">
                                <label class="form--label"><?php echo app('translator')->get('Roll No.'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-4">
                            <div class="input--group">
                                <input class="datepicker-here form-control form--control" name="start" data-date-format="yyyy" data-language='en' data-min-view="years" data-position='top left' data-view="years" type="text" required>
                                <label class="form--label"><?php echo app('translator')->get('Starting Year'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-4">
                            <div class="input--group">
                                <input class="datepicker-here form-control form--control" name="end" data-date-format="yyyy" data-language='en' data-min-view="years" data-position='top left' data-view="years" type="text">
                                <label class="form--label"><?php echo app('translator')->get('Ending Year'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-4">
                            <div class="input--group">
                                <input class="form-control form--control" name="result" type="number" min="0" step="any">
                                <label class="form--label"><?php echo app('translator')->get('Result'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-4">
                            <div class="input--group">
                                <input class="form-control form--control" name="out_of" type="number" min="0" step="any">
                                <label class="form--label"><?php echo app('translator')->get('Out Of'); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn--base w-100" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<!-- Education Information end-->
<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/vendor/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/vendor/datepicker.en.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .datepicker {
            z-index: 9999;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        $('.btnEditEducation').on('click', function() {
            let modal = $('#educationModal');
            let title = $(this).data('title');
            let action = $(this).data('action');
            let education = $(this).data('education');

            modal.find('.modal-title').text(title);
            modal.find('form').attr('action', action);
            modal.find('[name=degree]').val(education.degree);
            modal.find('[name=institute]').val(education.institute);
            modal.find('[name=field_of_study]').val(education.field_of_study);

            if (education.reg_no != 0) {
                modal.find('[name=reg_no]').val(education.reg_no);
            }
            if (education.roll_no != 0) {
                modal.find('[name=roll_no]').val(education.roll_no);
            }

            modal.find('[name=start]').val(education.start);
            modal.find('[name=end]').val(education.end);
            modal.find('[name=result]').val(education.result);
            modal.find('[name=out_of]').val(education.out_of);

            modal.modal('show');
        });

        $('.btnAddEducation').on('click', function() {
            let modal = $('#educationModal');
            let title = $(this).data('title');
            let action = $(this).data('action');

            modal.find('.modal-title').text(title);
            modal.find('form').attr('action', action);

            modal.modal('show');
        });

        $('#educationModal').on('hidden.bs.modal', function(event) {
            $(this).find('form').trigger("reset");

        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/profile_setting/education.blade.php ENDPATH**/ ?>