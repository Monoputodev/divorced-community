<!-- Express Interest Modal -->
<div aria-hidden="true" class="modal custom--modal fade" id="interestExpressModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Express Interest!'); ?></h5>
                <button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"></button>
            </div>
            <?php if($user): ?>
                <form action="<?php echo e(route('user.express.interest')); ?>" class="express-interest-form" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input name="interesting_id" type="hidden">
                        <?php if(checkValidityPeriod($user->limitation) && ($user->limitation->interest_express_limit == -1 || $user->limitation->interest_express_limit)): ?>
                            <div class="text-center">
                                <p class="fw-bold"><?php echo app('translator')->get('Remaining Express Interest'); ?> : <span class="remainingInterest"></span></p>
                                <?php if($user->limitation->interest_express_limit != -1): ?>
                                    <small class="text--danger"><?php echo app('translator')->get('"N.B: Expressing interest will cost 1 from your remaining interests"'); ?></small>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center">
                                <?php if(!checkValidityPeriod($user->limitation)): ?>
                                    <p class="fw-bold"><?php echo app('translator')->get('Your package has been expired'); ?> <span class="fw-600"><?php echo e(diffForHumans($user->limitation->expire_date)); ?></span></p>
                                <?php else: ?>
                                    <p class="fw-bold"><?php echo app('translator')->get('Remaining Express Interest'); ?> : <span class="remainingInterest"></span></p>
                                <?php endif; ?>
                                <?php if($general->default_package_id): ?>
                                    <small><?php echo app('translator')->get('Purchase package from '); ?>
                                        <a class="text--base" href="<?php echo e(route('packages')); ?>"><?php echo app('translator')->get('packages'); ?></a>
                                    </small>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <?php if(checkValidityPeriod($user->limitation) && ($user->limitation->interest_express_limit == -1 || $user->limitation->interest_express_limit)): ?>
                            <button class="btn btn--base w-100" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                        <?php else: ?>
                            <button class="btn btn--dark btn-sm" data-bs-dismiss="modal" type="button"><?php echo app('translator')->get('Close'); ?></button>
                        <?php endif; ?>
                    </div>
                </form>
            <?php else: ?>
                <div class="modal-body">
                    <p class="text-center"><?php echo app('translator')->get('Please login first'); ?></p>
                </div>
                <div class="modal-footer">
                    <a class="btn btn--dark btn--sm" href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login'); ?></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";

        $(document).on('click', '.interestExpressBtn', function() {
            let modal = $('#interestExpressModal');
            let interestingId = $(this).data('interesting_id');
            modal.find('[name=interesting_id]').val(interestingId);
            let route = "<?php echo e(route('user.interest.limit')); ?>";
            $.get(route,
                function(data) {
                    if (data == '-1') {
                        modal.find('.remainingInterest').text('Unlimited');
                    } else
                        modal.find('.remainingInterest').text(data);
                }
            );
            modal.modal('show');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/components/interest-express-modal.blade.php ENDPATH**/ ?>