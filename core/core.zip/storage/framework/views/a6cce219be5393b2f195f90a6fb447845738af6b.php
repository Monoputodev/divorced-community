<?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-12">
        <div class="search__right">
            <div class="row">
                <div class="col-md-4">
                    <div class="search__right-thumb">
                        <a href="<?php echo e(route('user.member.profile.public', $member->id)); ?>"><img
                                src="<?php echo e(getImage(getFilePath('userProfile') . '/' . $member->image, null, 'user')); ?>"
                                alt="<?php echo app('translator')->get('Member'); ?>"></a>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="search__right-content">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="member-info d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        
                                        <h5 class="member-info__name mt-0 mb-1"> <?php echo app('translator')->get('Member ID'); ?>:
                                            <span>
                                                <?php echo e($member->profile_id); ?>

                                            </span>
                                        </h5>
                                    </div>
                                    <?php if(@$member->limitation->package->price > 0): ?>
                                        <span class="badge badge--green"><?php echo e(__('Premium')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="search__right-details">
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Looking For'); ?></span></label>
                                        <span class="col-7">
                                            <?php if($member->looking_for == 1): ?>
                                                <?php echo app('translator')->get('Male'); ?>
                                            <?php elseif($member->looking_for == 2): ?>
                                                <?php echo app('translator')->get('Female'); ?>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Age'); ?></span></label>
                                        <span class="col-7">
                                            <?php
                                                if (@$member->basicInfo->birth_date) {
                                                    $age = now()->diffInYears($member->birth_date) . ' Years';
                                                } else {
                                                    $age = __('N/A');
                                                }
                                            ?>
                                            <?php echo e(__($age)); ?>

                                        </span>
                                    </div>
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Marital Status'); ?></span></label>
                                        <span class="col-7">
                                            <?php echo e(__($member->basicInfo->marital_status ?? __('N/A'))); ?>

                                        </span>
                                    </div>
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Language'); ?></span></label>
                                        <span class="col-7">
                                            <?php if($member->basicInfo && $member->basicInfo->language && count($member->basicInfo->language)): ?>
                                                <?php echo e(implode(', ', $member->basicInfo->language)); ?>

                                            <?php else: ?>
                                                <?php echo app('translator')->get('N/A'); ?>
                                            <?php endif; ?>

                                        </span>
                                    </div>
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Present Address'); ?></span></label>
                                        <span class="col-7">
                                            <?php if(@$member->basicInfo->present_address): ?>
                                                <?php echo e(__(@$member->basicInfo->present_address->city)); ?>

                                                <?php if(@$member->basicInfo->present_address->city): ?>
                                                    ,
                                                <?php endif; ?>
                                                <?php echo e(__(@$member->basicInfo->present_address->country)); ?>

                                            <?php else: ?>
                                                <?php echo app('translator')->get('N/A'); ?>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="search__right-details">
                                    <?php if(@$member->basicInfo->gender): ?>
                                        <div class="row member-details">
                                            <label class="col-5"><span><?php echo app('translator')->get('Gender'); ?></span></label>
                                            <span class="col-7">
                                                <?php if(@$member->basicInfo->gender == 'm'): ?>
                                                    <?php echo app('translator')->get('Male'); ?>
                                                <?php elseif(@$member->basicInfo->gender == 'f'): ?>
                                                    <?php echo app('translator')->get('Female'); ?>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Blood Group'); ?></span></label>
                                        <span class="col-7">
                                            <?php echo e(__(@$member->physicalAttributes->blood_group ?? __('N/A'))); ?>

                                        </span>
                                    </div>
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Religion'); ?></span></label>
                                        <span class="col-7">
                                            <?php echo e(__(@$member->basicInfo->religion ?? __('N/A'))); ?>

                                        </span>
                                    </div>
                                    <div class="row member-details">
                                        <label class="col-5"><span><?php echo app('translator')->get('Height'); ?></span></label>
                                        <span class="col-7">
                                            <?php echo e(@$member->physicalAttributes->height ? __(@$member->physicalAttributes->height) . ' Ft.' : __('N/A')); ?>

                                        </span>
                                    </div>
                                    <div class="row member-details">
                                        <label class="col-5">
                                            <span data-bs-toggle="tooltip"
                                                title="<?php echo app('translator')->get('Permanent Address'); ?>"><?php echo app('translator')->get('Per. Address'); ?></span>
                                        </label>
                                        <span class="col-7">
                                            <?php if(@$member->basicInfo->permanent_address): ?>
                                                <?php echo e(__(@$member->basicInfo->permanssent_address->city)); ?>

                                                <?php if(@$member->basicInfo->permanent_address->city): ?>
                                                    ,
                                                <?php endif; ?>
                                                <?php echo e(__(@$member->basicInfo->permanent_address->country)); ?>

                                            <?php else: ?>
                                                <?php echo app('translator')->get('N/A'); ?>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="search__right-expression">
                                    <ul class="search__right-list m-0 p-0">
                                        <li>
                                            <?php if(@$user && $user->interests->where('interesting_id', $member->id)->first()): ?>
                                                <a class="base-color" href="javascript:void(0)">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('Interested'); ?>
                                                </a>
                                            <?php elseif(
                                                @$user &&
                                                    $member->interests->where('interesting_id', @$user->id)->where('status', 0)->first()): ?>
                                                <a class="base-color" href="#">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('Response to Interest'); ?>
                                                </a>
                                            <?php elseif(
                                                @$user &&
                                                    $member->interests->where('interesting_id', @$user->id)->where('status', 1)->first()): ?>
                                                <a class="base-color" href="#">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('You Accepted Interest'); ?>
                                                </a>
                                            <?php else: ?>
                                                <a class="interestExpressBtn" data-interesting_id="<?php echo e($member->id); ?>"
                                                    href="javascript:void(0)">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('Interest'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <a class="confirmationBtn ignore"
                                                data-action="<?php echo e(route('user.ignore', $member->id)); ?>"
                                                data-question="<?php echo app('translator')->get('Are you sure, you want to ignore this member?'); ?>" href="javascript:void(0)">
                                                <i class="fas fa-user-times text--danger"></i><?php echo app('translator')->get('Ignore'); ?>
                                            </a>
                                        </li>
                                        <li>
                                            <?php if(@$user && $user->shortListedProfile->where('profile_id', $member->id)->first()): ?>
                                                <a class="removeFromShortList"
                                                    data-action="<?php echo e(route('user.remove.short.list')); ?>"
                                                    data-profile_id="<?php echo e($member->id); ?>" href="javascript:void(0)">
                                                    <i class="far fa-star"></i><?php echo app('translator')->get('Shortlisted'); ?>
                                                </a>
                                            <?php else: ?>
                                                <a class="addToShortList"
                                                    data-action="<?php echo e(route('user.add.short.list')); ?>"
                                                    data-profile_id="<?php echo e($member->id); ?>" href="javascript:void(0)">
                                                    <i class="far fa-star"></i><?php echo app('translator')->get('Shortlist'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <?php
                                                $report = $user ? $user->reports->where('complaint_id', $member->id)->first() : null;
                                            ?>
                                            <?php if(@$user && $report): ?>
                                                <a class="text--danger reportedUser"
                                                    data-report_reason="<?php echo e(__($report->reason)); ?>"
                                                    data-report_title="<?php echo e(__($report->title)); ?>"
                                                    href="javascript:void(0)">
                                                    <i class="fas fa-info-circle"></i><?php echo app('translator')->get('Reported'); ?>
                                                </a>
                                            <?php else: ?>
                                                <a href="javascript:void(0)"
                                                    onclick="showReportModal(<?php echo e($member->id); ?>)">
                                                    <i class="fas fa-info-circle"></i><?php echo app('translator')->get('Report'); ?>
                                                </a>
                                            <?php endif; ?>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-md-12">
        <div class="search__right">
            <div class="row">
                <div class="empty-table text-center">
                    <div class="empty-table__icon">
                        <i class="las la-frown"></i>
                    </div>
                    <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?></h6>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($members->hasPages()): ?>
    <div class="mt-3">
        <?php echo e(paginateLinks($members)); ?>

    </div>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal3568c4fc3f45162abec58241e67f5f8b50cc94e5 = $component; } ?>
<?php $component = App\View\Components\ReportShowModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('report-show-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ReportShowModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3568c4fc3f45162abec58241e67f5f8b50cc94e5)): ?>
<?php $component = $__componentOriginal3568c4fc3f45162abec58241e67f5f8b50cc94e5; ?>
<?php unset($__componentOriginal3568c4fc3f45162abec58241e67f5f8b50cc94e5); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/partials/members.blade.php ENDPATH**/ ?>