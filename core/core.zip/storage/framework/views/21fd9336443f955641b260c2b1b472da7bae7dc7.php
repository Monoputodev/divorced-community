 <!-- Partner Expectation -->
 <div class="public-profile__accordion accordion custom--accordion" id="accordionPanelsStayOpenExample">
     <div class="accordion-item partner-expectation">
         <h2 class="accordion-header" id="panelsStayOpen-partnerExp">
             <button class="accordion-button collapsed" data-bs-target="#panelsStayOpen-collapsePartnerExp" data-bs-toggle="collapse" type="button" aria-expanded="false" aria-expanded="false" aria-controls="panelsStayOpen-collapsePartnerExp">
                 <?php echo app('translator')->get('Partner Expectation'); ?>
             </button>
         </h2>
         <div class="accordion-collapse collapse" id="panelsStayOpen-collapsePartnerExp" aria-labelledby="panelsStayOpen-partnerExp">
             <div class="accordion-body">
                 <form class="partner-expectation-form" action="" autocomplete="off" method="POST">
                     <?php echo csrf_field(); ?>
                     <input name="method" type="hidden" value="partnerExpectation">
                     <div class="row gy-4">
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <textarea class="form-control form--control" name="general_requirement"><?php echo e(@$user->partnerExpectation->general_requirement); ?></textarea>
                                 <label class="form--label"><?php echo app('translator')->get('General Requirement'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <div class="input--group">
                                 <select name="country"class="form-select form-control form--control">
                                     <option value=""><?php echo app('translator')->get('Country'); ?></option>
                                     <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($country->country); ?>"><?php echo e(__($country->country)); ?>

                                         </option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                                 <label class="form--label"><?php echo app('translator')->get('Country'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="min_age" type="number" value="<?php echo e(@$user->partnerExpectation->min_age); ?>" min="0" step="any">
                                 <label class="form--label"><?php echo app('translator')->get('Minimum Age'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="max_age" type="number" value="<?php echo e(@$user->partnerExpectation->nax_age); ?>" min="0" step="any">
                                 <label class="form--label"><?php echo app('translator')->get('Maximum Age'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="min_height" type="number" value="<?php echo e(@$user->partnerExpectation->min_height); ?>" min="0" step="any">
                                 <label class="form--label"><?php echo app('translator')->get('Minimum Height'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="max_height" type="number" value="<?php echo e(@$user->partnerExpectation->max_height); ?>" min="0" step="any">
                                 <label class="form--label"><?php echo app('translator')->get('Maximum Height'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="max_weight" type="number" value="<?php echo e(@$user->partnerExpectation->max_weight); ?>" min="0" step="any">
                                 <label class="form--label"><?php echo app('translator')->get('Maximum Weight'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <select class="form-select form-control form--control" name="marital_status">
                                     <option value="" disabled><?php echo app('translator')->get('Select One'); ?></option>
                                     <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maritalStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($maritalStatus->title); ?>">
                                             <?php echo e(__($maritalStatus->title)); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <option value="0"><?php echo app('translator')->get('Does not matter'); ?></option>
                                 </select>
                                 <label class="form--label"><?php echo app('translator')->get('Marital Status'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <select class="form-select form-control form--control" name="religion">
                                     <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                     <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($religion->name); ?>"><?php echo e(__($religion->name)); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                                 <label class="form--label"><?php echo app('translator')->get('Religion'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="complexion" type="text" value="<?php echo e(@$user->partnerExpectation->complexion); ?>">
                                 <label class="form--label"><?php echo app('translator')->get('Complexion'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <select class="form-select form-control form--control" name="smoking_status">
                                     <option value="" disabled><?php echo app('translator')->get('Smoking Habits'); ?></option>
                                     <option value="0"><?php echo app('translator')->get('Does not matter'); ?></option>
                                     <option value="1"><?php echo app('translator')->get('Smoker'); ?></option>
                                     <option value="2"><?php echo app('translator')->get('Non-smoker'); ?></option>
                                 </select>
                                 <label class="form--label"><?php echo app('translator')->get('Smoking Habits'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <select class="form-select form-control form--control" name="drinking_status">
                                     <option value="" disabled><?php echo app('translator')->get('Select One'); ?></option>
                                     <option value="0"><?php echo app('translator')->get('Does not matter'); ?></option>
                                     <option value="2"><?php echo app('translator')->get('Restrained'); ?></option>
                                     <option value="1"><?php echo app('translator')->get('Drunker'); ?></option>
                                 </select>
                                 <label class="form--label"><?php echo app('translator')->get('Drinking Status'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="min_degree" type="text" value="<?php echo e(@$user->partnerExpectation->min_degree); ?>">
                                 <label class="form--label"><?php echo app('translator')->get('Minimum Degree'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="profession" type="text" value="<?php echo e(@$user->partnerExpectation->profession); ?>">
                                 <label class="form--label"><?php echo app('translator')->get('Profession'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <select class="form-control form--control select2-auto-tokenize2" name="language[]" multiple="multiple">
                                     <?php if(@$user->partnerExpectation): ?>
                                         <?php $__currentLoopData = @$user->partnerExpectation->language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($language); ?>" selected><?php echo e($language); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php endif; ?>
                                 </select>
                                 <label class="form--label"><?php echo app('translator')->get('Languages'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="personality" type="text" value="<?php echo e(@$user->partnerExpectation->personality); ?>">
                                 <label class="form--label"><?php echo app('translator')->get('Personality'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="financial_condition" type="text" value="<?php echo e(@$user->partnerExpectation->financial_condition); ?>">
                                 <label class="form--label"><?php echo app('translator')->get('Financial Condition'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-6">
                             <div class="input--group">
                                 <input class="form-control form--control" name="family_position" type="text" value="<?php echo e(@$user->partnerExpectation->family_position); ?>">
                                 <label class="form--label"><?php echo app('translator')->get('Family Position'); ?></label>
                             </div>
                         </div>
                         <div class="col-sm-12">
                             <button class="btn btn--base w-100 mt-0" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                         </div>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </div>
 <!-- Partner Expectation end-->

 <?php $__env->startPush('style-lib'); ?>
     <link href="<?php echo e(asset('assets/admin/css/vendor/select2.min.css')); ?>" rel="stylesheet">
 <?php $__env->stopPush(); ?>

 <?php $__env->startPush('script-lib'); ?>
     <script src="<?php echo e(asset('assets/admin/js/vendor/select2.min.js')); ?>"></script>
 <?php $__env->stopPush(); ?>

 <?php $__env->startPush('script'); ?>
     <script>
         "use strict";

         if (!$('.datepicker-here').val()) {
             $('.datepicker-here').datepicker({
                 autoClose: true,
             });
         }

         $('.skip-btn').on('click', function() {
             $('.info-form').submit();
         });

         $('.select2-auto-tokenize2').select2({
             tags: true,
             tokenSeparators: [',']
         });

         let partnerExpForm = $('.partner-expectation-form');
         let religion = "<?php echo e(@$user->partnerExpectation->religion); ?>";
         let gender = "<?php echo e(@$user->partnerExpectation->gender); ?>";
         let maritalStatus = "<?php echo e(@$user->partnerExpectation->marital_status); ?>";
         let smokingStatus = "<?php echo e(@$user->partnerExpectation->smoking_status); ?>";
         let drinkingStatus = "<?php echo e(@$user->partnerExpectation->drinking_status); ?>";
         let country = "<?php echo e(@$user->partnerExpectation->country); ?>";

         partnerExpForm.find('[name=religion]').val(religion);
         partnerExpForm.find('[name=gender]').val(gender);
         partnerExpForm.find('[name=marital_status]').val(maritalStatus);
         partnerExpForm.find('[name=smoking_status]').val(smokingStatus);
         partnerExpForm.find('[name=drinking_status]').val(drinkingStatus);
         partnerExpForm.find('[name=country]').val(country);
     </script>
 <?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/profile_setting/partner_expectation.blade.php ENDPATH**/ ?>