<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="table-responsive--md">
            <table class="custom--table table">
                <?php if($shortlists->count()): ?>
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('S.N'); ?></th>
                            <th><?php echo app('translator')->get('Name'); ?></th>
                            <th><?php echo app('translator')->get('Age'); ?></th>
                            <th><?php echo app('translator')->get('Religion'); ?></th>
                            <th><?php echo app('translator')->get('Country'); ?></th>
                            <th><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                    </thead>
                <?php endif; ?>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $shortlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($shortlists->firstItem() + $loop->index); ?>

                            </td>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <div class="user user--sm">
                                        <img class="user__img" src="<?php echo e(getImage(getFilePath('userProfile') . '/' . @$shortlist->profile->image, getFileSize('userProfile'), 'user')); ?>" alt="<?php echo app('translator')->get('Image'); ?>" />
                                    </div>
                                    <h6 class="user__text d-inline-block mt-0 mb-0">
                                        <a href="<?php echo e(route('user.member.profile.public', $shortlist->profile_id)); ?>"><?php echo e(__($shortlist->profile->firstname == '' ? $shortlist->profile->username : $shortlist->profile->fullname)); ?></a>
                                    </h6>
                                </div>
                            </td>
                            <td><?php echo e(@$shortlist->profile->basicInfo->birth_date ? now()->diffInYears(@$shortlist->profile->basicInfo->birth_date) : 'N/A'); ?></td>
                            <td><?php echo e(__(@$shortlist->profile->basicInfo->religion ?? 'N/A')); ?></td>
                            <td><?php echo e(__(@$shortlist->profile->basicInfo->present_address->country ?? 'N/A')); ?></td>
                            <td>
                                <?php if($user->interests->where('interesting_id', $shortlist->profile_id)->first()): ?>
                                    <a class="icon-anchor btn--info" data-bs-toggle="tooltip" href="javascript:void(0)" title="<?php echo app('translator')->get('Interest Expressed'); ?>"><i class="las la-heart"></i></a>
                                <?php elseif($shortlist->profile->interests->where('interesting_id', $user->id)->where('status', 0)->first()): ?>
                                    <a class="icon-anchor btn--info" data-bs-toggle="tooltip" href="javascript:void(0)" title="<?php echo app('translator')->get('Response to Interest'); ?>"><i class="las la-heart"></i></a>
                                <?php elseif($shortlist->profile->interests->where('interesting_id', $user->id)->where('status', 1)->first()): ?>
                                    <a class="icon-anchor btn--info" data-bs-toggle="tooltip" href="javascript:void(0)" title="<?php echo app('translator')->get('You Accepted Interest'); ?>"><i class="las la-heart"></i></a>
                                <?php else: ?>
                                    <a class="icon-anchor btn--base-two interestExpressBtn" data-bs-toggle="tooltip" data-interesting_id="<?php echo e($shortlist->profile_id); ?>" href="javascript:void(0)" title="<?php echo app('translator')->get('Express Interest'); ?>"><i class="las la-heart"></i></a>
                                <?php endif; ?>

                                <a class="icon-anchor btn--danger remove" data-action="<?php echo e(route('user.shortlist.remove', $shortlist->id)); ?>" href="javascript:void(0)"><i class="las la-trash-alt"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="100">
                                <div class="empty-table text-center">
                                    <div class="empty-table__icon">
                                        <i class="las la-frown"></i>
                                    </div>
                                    <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?></h6>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
            <?php if($shortlists->hasPages()): ?>
                <div class="mt-3">
                    <?php echo e(paginateLinks($shortlists)); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b = $component; } ?>
<?php $component = App\View\Components\InterestExpressModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('interest-express-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InterestExpressModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b)): ?>
<?php $component = $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b; ?>
<?php unset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="">
        <div class="input-group">
            <input class="form-control form--control bg-white" name="search" type="text" value="<?php echo e(request()->search); ?>">
            <button class="input-group-text btn btn--base" type="submit"><i class="las la-search"></i></button>
        </div>
    </form>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('.remove').on('click', function() {
            let url = $(this).data('action');
            let tr = $(this).parents('tr');
            let table = $(this).parents('table');
            $.ajax({
                type: "post",
                url: url,
                success: function(response) {
                    console.log(response);
                    if (response.success) {
                        notify('success', response.success);
                        tr.remove();
                        if (!table.find('tbody').find('tr').length) {
                            table.find('thead').remove();
                            table.find('tbody').append(`
                            <tr>
                                <td colspan="100">
                                    <div class="empty-table text-center">
                                        <div class="empty-table__icon">
                                            <i class="las la-frown"></i>
                                        </div>
                                        <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?></h6>
                                    </div>
                                </td>
                            </tr>
                            `);
                        }
                    } else {
                        notify('error', response.error);
                    }
                }
            });
        });

        $('.express-interest-form').on('submit', function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            let url = $(this).attr('action');
            let modal = $('#interestExpressModal');
            let id = modal.find('[name=interesting_id]').val();
            let button = $(`.interestExpressBtn[data-interesting_id="${id}"]`);
            let td = $(`.interestExpressBtn[data-interesting_id="${id}"]`).parents('td');
            $.ajax({
                type: "post",
                url: url,
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    modal.modal('hide');
                    if (response.success) {
                        notify('success', response.success);
                        button.remove();
                        td.prepend(`
                        <a href="javascript:void(0)" class="icon-anchor btn--info" data-bs-toggle="tooltip" title="<?php echo app('translator')->get('Interest Expressed'); ?>"><i class="las la-heart"></i></a>
                        `);
                    } else {
                        notify('error', response.error);
                    }
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/shortlists.blade.php ENDPATH**/ ?>