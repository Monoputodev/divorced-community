<!-- Career Information -->
<div class="public-profile__accordion accordion custom--accordion" id="accordionPanelsStayOpenExample">
    <div class="accordion-item">
        <h2 class="accordion-header" id="panelsStayOpen-careerInfo">
            <button class="accordion-button collapsed" data-bs-target="#panelsStayOpen-collapseCareerInfo" data-bs-toggle="collapse" type="button" aria-expanded="false" aria-controls="panelsStayOpen-collapseCareerInfo">
                <?php echo app('translator')->get('Career Information'); ?>
            </button>
        </h2>
        <div class="accordion-collapse collapse" id="panelsStayOpen-collapseCareerInfo" aria-labelledby="panelsStayOpen-careerInfo">
            <div class="accordion-body">
                <div class="row">
                    <div class="col-12 pb-4 text-end">
                        <button class="btn btn-sm btn--base btnAddCareer mt-0" data-action="<?php echo e(route('user.career.update')); ?>" data-title="<?php echo app('translator')->get('Add Career Information'); ?>">
                            <i class="las la-plus"> <?php echo app('translator')->get('Add New'); ?></i>
                        </button>
                    </div>
                    <div class="col-md-12">
                        <div class="table-responsive--md">
                            <table class="custom--table table table">
                                <?php if($user->careerInfo->count()): ?>
                                    <thead>
                                        <tr>
                                            <th><?php echo app('translator')->get('S.N'); ?></th>
                                            <th><?php echo app('translator')->get('Company'); ?></th>
                                            <th><?php echo app('translator')->get('Designation'); ?></th>
                                            <th><?php echo app('translator')->get('Start'); ?></th>
                                            <th><?php echo app('translator')->get('End'); ?></th>
                                            <th><?php echo app('translator')->get('Action'); ?></th>
                                        </tr>
                                    </thead>
                                <?php endif; ?>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $user->careerInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e(__($career->company)); ?></td>
                                            <td><?php echo e(__($career->designation)); ?></td>
                                            <td><?php echo e($career->start); ?></td>
                                            <td><?php echo e($career->end ?? __('Running')); ?>

                                            </td>
                                            <td>
                                                <button class="icon-btn btn--info btnEditCareer" data-action="<?php echo e(route('user.career.update', $career->id)); ?>" data-bs-toggle="tooltip" data-career="<?php echo e($career); ?>" data-title="<?php echo app('translator')->get('Update Career Information'); ?>" type="button" title="<?php echo app('translator')->get('Edit'); ?>">
                                                    <i class="la la-edit"></i>
                                                </button>
                                                <button class="icon-btn btn--danger confirmationBtn" data-action="<?php echo e(route('user.career.delete', $career->id)); ?>" data-bs-toggle="tooltip" data-question="<?php echo app('translator')->get('Are your sure, you want to delete this career information?'); ?>" title="<?php echo app('translator')->get('Delete'); ?>">
                                                    <i class="las la-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="100">
                                                <div class="empty-table text-center">
                                                    <div class="empty-table__icon">
                                                        <i class="las la-frown"></i>
                                                    </div>
                                                    <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?></h6>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--Career Modal -->
<div class="modal custom--modal fade" id="careerModal" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
            </div>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row gy-4">
                        <div class="col-sm-12">
                            <div class="input--group">
                                <input class="form-control form--control" name="company" type="text" required>
                                <label class="form--label"><?php echo app('translator')->get('Company'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="input--group">
                                <input class="form-control form--control" name="designation" type="text" required>
                                <label class="form--label"><?php echo app('translator')->get('Designation'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input--group">
                                <input class="datepicker-here form-control form--control" name="start" data-date-format="yyyy" data-language='en' data-min-view="years" data-position='top left' data-view="years" type="text">
                                <label class="form--label"><?php echo app('translator')->get('Starting Year'); ?></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input--group">
                                <input class="datepicker-here form-control form--control" name="end" data-date-format="yyyy" data-language='en' data-min-view="years" data-position='top left' data-view="years" type="text">
                                <label class="form--label"><?php echo app('translator')->get('Ending Year'); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn--base w-100" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<!-- Career Information end-->
<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/vendor/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/vendor/datepicker.en.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .datepicker {
            z-index: 9999;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";

        $('.btnEditCareer').on('click', function() {
            let modal = $('#careerModal');
            let title = $(this).data('title');
            let action = $(this).data('action');
            let career = $(this).data('career');

            modal.find('.modal-title').text(title);
            modal.find('form').attr('action', action);
            modal.find('[name=company]').val(career.company);
            modal.find('[name=designation]').val(career.designation);
            modal.find('[name=start]').val(career.start);
            modal.find('[name=end]').val(career.end);

            modal.modal('show');
        });

        $('.btnAddCareer').on('click', function() {
            let modal = $('#careerModal');
            let title = $(this).data('title');
            let action = $(this).data('action');

            modal.find('.modal-title').text(title);
            modal.find('form').attr('action', action);

            modal.modal('show');
        });

        $('#careerModal').on('hidden.bs.modal', function(event) {
            $(this).find('form').trigger("reset");

        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/profile_setting/career.blade.php ENDPATH**/ ?>