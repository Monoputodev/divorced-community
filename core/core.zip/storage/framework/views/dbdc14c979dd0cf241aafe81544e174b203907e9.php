<?php $__env->startSection('content'); ?>
    <?php if(checkValidityPeriod($user->limitation) && ($user->limitation->image_upload_limit == '-1' || $user->limitation->image_upload_limit - $user->galleries->count() > 0)): ?>
        <div class="row">
            <form action="" enctype="multipart/form-data" method="post">
                <?php echo csrf_field(); ?>
                <div class="input-images"></div>
                <button class="btn btn--base w-100 mt-3 mb-3" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
            </form>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-info" role="alert">
                    <?php if(!checkValidityPeriod($user->limitation)): ?>
                        <p class="mb-0"><?php echo app('translator')->get('Your package has been expired'); ?> <span class="fw-600"><?php echo e(diffForHumans($user->limitation->expire_date)); ?></span></p>
                    <?php else: ?>
                        <p class="mb-0"><?php echo app('translator')->get('Your image upload limit is over!'); ?></p>
                    <?php endif; ?>
                    <?php if($general->default_package_id): ?>
                        <small><?php echo app('translator')->get('Please remove some images. Or purchase package from '); ?>
                            <a class="text--base" href="<?php echo e(route('packages')); ?>"><?php echo app('translator')->get('packages'); ?></a>
                        </small>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if($maxLimit != -1 && $user->galleries->count() > $maxLimit): ?>
        <div class="text-end">
            <button class="btn btn--danger confirmationBtn mb-3" data-action="<?php echo e(route('user.gallery.unpublished.delete')); ?>" data-question="<?php echo app('translator')->get('Are you sure, you want to delete all unpublished images?'); ?>" type="button"><i class="las la-trash-alt"></i><?php echo app('translator')->get('Delete All unpublished image'); ?></button>
        </div>
    <?php endif; ?>
    <?php if($user->galleries->count()): ?>
        <div class="row g-0 filter-container p-0">
            <?php $__currentLoopData = $user->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 grid-item" data-category="1" data-sort="value">
                    <div class="profile-gallery position-relative">
                        <?php if($loop->iteration > $maxLimit): ?>
                            <span class="image-status"><?php echo app('translator')->get('Unpublished'); ?></span>
                        <?php endif; ?>
                        <div class="profile-gallery__thumb">
                            <img src="<?php echo e(getImage(getFilePath('gallery') . '/' . $userImage->image)); ?>" alt="">
                            <div class="profile-gallery__icon">
                                <a class="magnific-gallery" href="<?php echo e(getImage(getFilePath('gallery') . '/' . $userImage->image)); ?>"><i class="fas fa-search-plus"></i> </a>
                                <button class="delete-icon" data-gallery_id="<?php echo e($userImage->id); ?>" type="button"><i class="fas fa-trash-alt"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="modal fade" id="deleteGallery" role="dialog" tabindex="-1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Confirmation Alert!'); ?></h5>
                    <button class="close" data-bs-dismiss="modal" type="button" aria-label="Close">
                        <i class="las la-times"></i>
                    </button>
                </div>
                <form action="<?php echo e(route('user.gallery.delete')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input name="gallery_id" type="hidden">
                    <div class="modal-body text-center">
                        <p class="mb-0"><?php echo e(__('Are you sure that you want to delete this image?')); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn--dark btn--sm" data-bs-dismiss="modal" type="button"><?php echo app('translator')->get('No'); ?></button>
                        <button class="btn btn--base btn--sm" type="submit"><?php echo app('translator')->get('Yes'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if($user->galleries->count() > $maxLimit): ?>
        <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .image-status {
            right: 5px;
            top: 5px;
            padding: 5px;
            border-radius: 5px;
            background-color: #f73f1e;
            color: #fff;
            position: absolute;
            font-size: 12px;
            z-index: 1;
        }

        .modal-body p,
        .modal-body small {
            font-size: 13px;
        }

        .modal-header button {
            border: none;
            border-radius: 50%;
            margin-top: 10px;
        }

        .modal-title {
            margin-top: 15px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <!--Image uploader-->
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/image-uploader.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <!--Image uploader-->
    <link href="<?php echo e(asset($activeTemplateTrue . 'css/image-uploader.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";
            let userImageUploadLimit = <?php echo e($user->limitation->image_upload_limit); ?>;
            let totalUploaded = <?php echo e($user->galleries->count()); ?>;
            let options = {};
            if (userImageUploadLimit != -1) {
                let countLimit = userImageUploadLimit - totalUploaded;
                let uploadLimitCal = countLimit > 0 ? countLimit : 1;
                options = {
                    label: `<?php echo app('translator')->get('Drag & Drop files here or click to browse. Select maximum'); ?> ${uploadLimitCal} ${uploadLimitCal==1 ? "<?php echo app('translator')->get('image'); ?>" : "<?php echo app('translator')->get('images'); ?>"}`,
                    maxFiles: uploadLimitCal
                };
            }
            $('.input-images').imageUploader(options);

            $('.delete-icon').on('click', function() {
                let modal = $('#deleteGallery');
                let galleryId = $(this).data('gallery_id');

                modal.find('[name=gallery_id]').val(galleryId);
                modal.modal('show');
            })

        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/gallery.blade.php ENDPATH**/ ?>