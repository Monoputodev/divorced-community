<?php $__env->startSection('content'); ?>
    <?php
        $kycInstruction = getContent('kyc_instruction.content', true);
    ?>
    <?php if(auth()->user()->kv == 0): ?>
        <div class="alert alert-info" role="alert">
            <h6 class="alert-heading my-0"><?php echo app('translator')->get('KYC Verification required'); ?></h6>
            <hr class="my-2">
            <p class="mb-0"> <?php echo e(__($kycInstruction->data_values->verification_instruction)); ?> <a class="text--base" href="<?php echo e(route('user.kyc.form')); ?>"><?php echo app('translator')->get('Click Here to Verify'); ?></a></p>
        </div>
    <?php elseif(auth()->user()->kv == 2): ?>
        <div class="alert alert-warning" role="alert">
            <h6 class="alert-heading my-0"><?php echo app('translator')->get('KYC Verification pending'); ?></h6>
            <hr class="my-2">
            <p class="mb-0"> <?php echo e(__($kycInstruction->data_values->pending_instruction)); ?> <a class="text--base" href="<?php echo e(route('user.kyc.data')); ?>"><?php echo app('translator')->get('See KYC Data'); ?></a></p>
        </div>
    <?php endif; ?>
    <!-- Dashboard  -->
    <div class="row gy-4 justify-content-center">
        <div class="dashboard-wrapper col-xxl-4 col-md-6">
            <div class="dashboard-card d-flex align-items-center flex-wrap">
                <div class="dashboard-card__icon">
                    <i class="far fa-heart"></i>
                </div>
                <div class="dashboard-card__content text-start">
                    <h4 class="dashboard-card__title d-block mt-0"><?php echo e(userLimitation()['interest_express_limit']); ?></h5>
                        <span class="dashboard-card__desc"><?php echo app('translator')->get('Remaining Interests'); ?></span>
                </div>
            </div>
        </div>
        <div class="dashboard-wrapper col-xxl-4 col-md-6">
            <div class="dashboard-card d-flex align-items-center flex-wrap">
                <div class="dashboard-card__icon">
                    <i class="fas fa-phone"></i>
                </div>
                <div class="dashboard-card__content text-start">
                    <h4 class="dashboard-card__title d-block mt-0"><?php echo e(userLimitation()['contact_view_limit']); ?></h5>
                        <span class="dashboard-card__desc"><?php echo app('translator')->get('Remaining Contact View'); ?></span>
                </div>
            </div>
        </div>
        <div class="dashboard-wrapper col-xxl-4 col-md-6">
            <div class="dashboard-card d-flex align-items-center flex-wrap">
                <div class="dashboard-card__icon">
                    <i class="fas fa-cloud-upload-alt"></i>
                </div>
                <div class="dashboard-card__content text-start">
                    <h4 class="dashboard-card__title d-block mt-0"><?php echo e($user->limitation->image_upload_limit == -1 ? trans('Unlimited') : ($user->limitation->image_upload_limit - $user->total_images > 0 ? $user->limitation->image_upload_limit - $user->total_images : 0)); ?></h5>
                        <span class="dashboard-card__desc"><?php echo app('translator')->get('Remaining Image Upload'); ?></span>
                </div>
            </div>
        </div>
        <div class="dashboard-wrapper col-xxl-4 col-md-6">
            <div class="dashboard-card d-flex align-items-center flex-wrap">
                <div class="dashboard-card__icon">
                    <i class="fas fa-list"></i>
                </div>
                <div class="dashboard-card__content text-start">
                    <h4 class="dashboard-card__title d-block mt-0"><?php echo e($user->totalShortlisted); ?></h5>
                        <span class="dashboard-card__desc"><?php echo app('translator')->get('Total Shortlisted'); ?></span>
                </div>
            </div>
        </div>
        <div class="dashboard-wrapper col-xxl-4 col-md-6">
            <div class="dashboard-card d-flex align-items-center flex-wrap">
                <div class="dashboard-card__icon">
                    <i class="fas fa-heartbeat"></i>
                </div>
                <div class="dashboard-card__content text-start">
                    <h4 class="dashboard-card__title d-block mt-0"><?php echo e($user->interestSent); ?></h5>
                        <span class="dashboard-card__desc"><?php echo app('translator')->get('Interest Sent'); ?></span>
                </div>
            </div>
        </div>
        <div class="dashboard-wrapper col-xxl-4 col-md-6">
            <div class="dashboard-card d-flex align-items-center flex-wrap">
                <div class="dashboard-card__icon">
                    <i class="fas fa-heart"></i>
                </div>
                <div class="dashboard-card__content text-start">
                    <h4 class="dashboard-card__title d-block mt-0"><?php echo e($user->totalInterestRequests); ?></h5>
                        <span class="dashboard-card__desc"><?php echo app('translator')->get('Interest Requests'); ?></span>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card custom--card package--card">
                <h5 class="card-header mt-0"><?php echo app('translator')->get('Current Package'); ?></h5>
                <div class="card-body">
                    <div class="row">
                        <h5><?php echo e(__($user->limitation->package_id ? $user->limitation->package->name : 'Global Package')); ?></h5>
                        <div class="package-options d-flex flex-wrap">
                            <i class="las la-check mt-1"></i>
                            <span class="ps-2">
                                <?php if($user->limitation->interest_express_limit != -1): ?>
                                    <?php echo e($user->limitation->interest_express_limit); ?>

                                <?php else: ?>
                                    <?php echo app('translator')->get('Unlimited '); ?>
                                <?php endif; ?>
                                <?php echo app('translator')->get('Express Interests'); ?>
                            </span>
                        </div>
                        <div class="package-options d-flex mt-1 flex-wrap">
                            <i class="las la-check mt-1"></i>
                            <span class="ps-2">
                                <?php echo e($user->limitation->contact_view_limit == -1 ? 'Unlimited ' : $user->limitation->contact_view_limit); ?>

                                <?php echo app('translator')->get('Contact View'); ?>
                            </span>
                        </div>

                        <div class="package-options d-flex mt-1 flex-wrap">
                            <i class="las la-check mt-1"></i>
                            <span class="ps-2">
                                <?php echo e($user->limitation->image_upload_limit == -1 ? 'Unlimited ' : $user->limitation->image_upload_limit); ?>

                                <?php echo app('translator')->get('Image Upload'); ?>
                            </span>
                        </div>
                        <div class="mt-3">
                            <div>
                                <?php if(checkValidityPeriod($user->limitation)): ?>
                                    <?php echo app('translator')->get('Package expiry date'); ?> : <?php echo e(showDateTime($user->limitation->expire_date, 'd M, Y')); ?>

                                <?php else: ?>
                                    <?php echo app('translator')->get('Package expired'); ?> : <?php echo e(diffForHumans($user->limitation->expire_date)); ?>

                                <?php endif; ?>
                            </div>
                            <a class="btn btn--base mt-3" href="<?php echo e(route('packages')); ?>"><?php echo app('translator')->get('Upgrade Package'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <h5><?php echo app('translator')->get('Latest Interests'); ?></h5>
            <?php echo $__env->make($activeTemplate . 'partials.interest_table', ['interests' => $user->interests, 'pagination' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-12">
            <h5><?php echo app('translator')->get('Latest Interest Requests'); ?></h5>
            <?php echo $__env->make($activeTemplate . 'partials.interest_request_table', ['interestRequests' => $user->interestRequests, 'pagination' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <!-- Dashboard End -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .wallet--card.custom--card .card-body {
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>