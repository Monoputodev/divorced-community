<?php if(@$member->partnerExpectation): ?>
    <div class="col-md-6">
        <div class="search__right-details">
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Religion'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->religion ? __($member->partnerExpectation->religion) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Marital Status'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->marital_status ? __($member->partnerExpectation->marital_status) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Country'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->country ? __($member->partnerExpectation->country) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Minimum Age'); ?></span>
                </label>
                <span class="col-7">
                    <?php if($member->partnerExpectation->min_age): ?>
                        <?php echo e($member->partnerExpectation->min_age); ?>

                        <?php echo app('translator')->get('years'); ?>
                    <?php else: ?>
                        <?php echo app('translator')->get('N/A'); ?>
                    <?php endif; ?>
                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Minimum Height'); ?></span>
                </label>
                <span class="col-7">
                    <?php if($member->partnerExpectation->min_height): ?>
                        <?php echo e($member->partnerExpectation->min_height); ?>

                        <?php echo app('translator')->get('Ft.'); ?>
                    <?php else: ?>
                        <?php echo app('translator')->get('N/A'); ?>
                    <?php endif; ?>
                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Maximum Age'); ?></span>
                </label>
                <span class="col-7">
                    <?php if($member->partnerExpectation->max_age): ?>
                        <?php echo e($member->partnerExpectation->max_age); ?>

                        <?php echo app('translator')->get('years'); ?>
                    <?php else: ?>
                        <?php echo app('translator')->get('N/A'); ?>
                    <?php endif; ?>
                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Maximum Weight'); ?></span>
                </label>
                <span class="col-7">
                    <?php if($member->partnerExpectation->max_weight): ?>
                        <?php echo e($member->partnerExpectation->max_weight); ?>

                        <?php echo app('translator')->get('KG'); ?>
                    <?php else: ?>
                        <?php echo app('translator')->get('N/A'); ?>
                    <?php endif; ?>
                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Language'); ?></span>
                </label>
                <span class="col-7">
                    <?php if(@$member->partnerExpectation): ?>
                        <?php if(count($member->partnerExpectation->language)): ?>
                            <?php echo e(implode(', ', $member->partnerExpectation->language)); ?>

                        <?php else: ?>
                            <?php echo app('translator')->get('N/A'); ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php echo app('translator')->get('N/A'); ?>
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="search__right-details">
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Minimum Degree'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->min_degree ? __($member->partnerExpectation->min_degree) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Profession'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->profession ? __($member->partnerExpectation->profession) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Smoking Habits'); ?></span>
                </label>
                <span class="col-7">
                    <?php if($member->partnerExpectation->smoking_status == 0): ?>
                        <?php echo app('translator')->get('Does not matter'); ?>
                    <?php elseif($member->partnerExpectation->smoking_status == 1): ?>
                        <?php echo app('translator')->get('Smoker'); ?>
                    <?php elseif($member->partnerExpectation->smoking_status == 2): ?>
                        <?php echo app('translator')->get('Non smoker'); ?>
                    <?php endif; ?>
                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Drinking Status'); ?></span>
                </label>
                <span class="col-7">
                    <?php if($member->partnerExpectation->drinking_status == 0): ?>
                        <?php echo app('translator')->get('Does not matter'); ?>
                    <?php elseif($member->partnerExpectation->drinking_status == 1): ?>
                        <?php echo app('translator')->get('Drunker'); ?>
                    <?php elseif($member->partnerExpectation->drinking_status == 2): ?>
                        <?php echo app('translator')->get('Restranied / Non-drunker'); ?>
                    <?php endif; ?>
                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Personality'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->personality ? __($member->partnerExpectation->personality) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Financial Condition'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->financial_condition ? __($member->partnerExpectation->financial_condition) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('Family Position'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->family_position ? __($member->partnerExpectation->family_position) : 'N/A'); ?>

                </span>
            </div>
            <div class="row member-details">
                <label class="col-5"><span><?php echo app('translator')->get('General Requirement'); ?></span>
                </label>
                <span class="col-7">
                    <?php echo e($member->partnerExpectation->family_position ? __($member->partnerExpectation->family_position) : 'N/A'); ?>

                </span>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="col-md-12">
        <div class="empty-table text-center">
            <div class="empty-table__icon">
                <i class="las la-frown"></i>
            </div>
            <h6 class="empty-table__text mt-1">
                <?php echo e(__($emptyMessage)); ?></h6>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/members/partner_expectation.blade.php ENDPATH**/ ?>