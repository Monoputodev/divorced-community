<?php
    $memberContent = getContent('member.content', true);
    $memberElement = App\Models\User::all();
    $user = auth()->user();
?>

<!-- Member Section  -->
<div class="section section--bg">
    <div class="section__head">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10 col-xl-6">
                    <h2 class="mt-0 text-center"><?php echo e(__(@$memberContent->data_values->heading)); ?></h2>
                    <p class="section__para mx-auto mb-0 text-center">
                        <?php echo e(__(@$memberContent->data_values->subheading)); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>




    <div class="container">
        <div class="row member-slider">
            <?php $__currentLoopData = $memberElement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="m-3">
                    <div class="card text-white card-has-bg click-col"
                        style="background-image:url('<?php echo e(getImage(getFilePath('userProfile') . '/' . $member->image, null, 'user')); ?>');background-size:cover;background-repeat:no-repeat;">
                        <div class="card-img-overlay d-flex flex-column">
                            <div class="card-body">
                                <h4 class="card-title mt-0 "><a class="text-white" herf="#">
                                        <?php echo e($member->profile_id); ?></a></h4>

                            </div>
                            <div class="card-footer">
                                <div class="search__right-expression">
                                    <ul class="search__right-list m-0 p-0">
                                        <li>
                                            <?php if(@$user && $user->interests->where('interesting_id', $member->id)->first()): ?>
                                                <a class="base-color" href="javascript:void(0)">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('Interested'); ?>
                                                </a>
                                            <?php elseif(
                                                @$user &&
                                                    $member->interests->where('interesting_id', @$user->id)->where('status', 0)->first()): ?>
                                                <a class="base-color" href="#">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('Response to Interest'); ?>
                                                </a>
                                            <?php elseif(
                                                @$user &&
                                                    $member->interests->where('interesting_id', @$user->id)->where('status', 1)->first()): ?>
                                                <a class="base-color" href="#">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('You Accepted Interest'); ?>
                                                </a>
                                            <?php else: ?>
                                                <a class="interestExpressBtn" data-interesting_id="<?php echo e($member->id); ?>"
                                                    href="javascript:void(0)">
                                                    <i class="fas fa-heart"></i><?php echo app('translator')->get('Interest'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <a class="confirmationBtn ignore"
                                                data-action="<?php echo e(route('user.ignore', $member->id)); ?>"
                                                data-question="<?php echo app('translator')->get('Are you sure, you want to ignore this member?'); ?>" href="javascript:void(0)">
                                                <i class="fas fa-user-times text--danger"></i><?php echo app('translator')->get('Ignore'); ?>
                                            </a>
                                        </li>
                                        <li>
                                            <?php if(@$user && $user->shortListedProfile->where('profile_id', $member->id)->first()): ?>
                                                <a class="removeFromShortList"
                                                    data-action="<?php echo e(route('user.remove.short.list')); ?>"
                                                    data-profile_id="<?php echo e($member->id); ?>" href="javascript:void(0)">
                                                    <i class="far fa-star"></i><?php echo app('translator')->get('Shortlisted'); ?>
                                                </a>
                                            <?php else: ?>
                                                <a class="addToShortList"
                                                    data-action="<?php echo e(route('user.add.short.list')); ?>"
                                                    data-profile_id="<?php echo e($member->id); ?>" href="javascript:void(0)">
                                                    <i class="far fa-star"></i><?php echo app('translator')->get('Shortlist'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <?php
                                                $report = $user ? $user->reports->where('complaint_id', $member->id)->first() : null;
                                            ?>
                                            <?php if(@$user && $report): ?>
                                                <a class="text--danger reportedUser"
                                                    data-report_reason="<?php echo e(__($report->reason)); ?>"
                                                    data-report_title="<?php echo e(__($report->title)); ?>"
                                                    href="javascript:void(0)">
                                                    <i class="fas fa-info-circle"></i><?php echo app('translator')->get('Reported'); ?>
                                                </a>
                                            <?php else: ?>
                                                <a href="javascript:void(0)"
                                                    onclick="showReportModal(<?php echo e($member->id); ?>)">
                                                    <i class="fas fa-info-circle"></i><?php echo app('translator')->get('Report'); ?>
                                                </a>
                                            <?php endif; ?>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <?php if (isset($component)) { $__componentOriginal4fc9a5717cb2cefd46c47fa7ff11f08c5a01ae29 = $component; } ?>
<?php $component = App\View\Components\ReportModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('report-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ReportModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fc9a5717cb2cefd46c47fa7ff11f08c5a01ae29)): ?>
<?php $component = $__componentOriginal4fc9a5717cb2cefd46c47fa7ff11f08c5a01ae29; ?>
<?php unset($__componentOriginal4fc9a5717cb2cefd46c47fa7ff11f08c5a01ae29); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b = $component; } ?>
<?php $component = App\View\Components\InterestExpressModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('interest-express-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InterestExpressModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b)): ?>
<?php $component = $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b; ?>
<?php unset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
    </div>







    <?php $__env->startPush('script'); ?>
        <script>
            "use strict";

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            let config = {
                routes: {
                    addShortList: "<?php echo e(route('user.add.short.list')); ?>",
                    removeShortList: "<?php echo e(route('user.remove.short.list')); ?>",
                },
                loadingText: {
                    addShortList: "<?php echo e(trans('Shortlisting')); ?>",
                    removeShortList: "<?php echo e(trans('Removing')); ?>",
                    interestExpress: "<?php echo e(trans('Processing')); ?>",
                },
                buttonText: {
                    addShortList: "<?php echo e(trans('Shortlist')); ?>",
                    removeShortList: "<?php echo e(trans('Shortlisted')); ?>",
                    interestExpressed: "<?php echo e(trans('Interested')); ?>",
                    expressInterest: "<?php echo e(trans('Interest')); ?>",
                }
            }

            $('.express-interest-form').on('submit', function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                let url = $(this).attr('action');
                let modal = $('#interestExpressModal');
                let id = modal.find('[name=interesting_id]').val();
                let li = $(`.interestExpressBtn[data-interesting_id="${id}"]`).parents('li');
                $.ajax({
                    type: "post",
                    url: url,
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function() {
                        $(li).find('a').html(
                            `<i class="fas fa-heart"></i>${config.loadingText.interestExpress}..`);
                    },
                    success: function(response) {
                        modal.modal('hide');
                        if (response.success) {
                            notify('success', response.success);
                            li.find('a').remove();
                            li.html(`<a href="javascript:void(0)" class="base-color">
                            <i class="fas fa-heart"></i>${config.buttonText.interestExpressed}
                        </a>`);
                        } else {
                            notify('error', response.error);
                            li.html(`<a href="javascript:void(0)" class="interestExpressBtn" data-interesting_id="${id}">
                                <i class="fas fa-heart"></i>${config.buttonText.expressInterest}
                        </a>`);
                        }
                    }
                });
            })
        </script>
        <script src="<?php echo e(asset($activeTemplateTrue . 'js/member.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

</div>
<!-- Member Section End -->

<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/sections/member.blade.php ENDPATH**/ ?>