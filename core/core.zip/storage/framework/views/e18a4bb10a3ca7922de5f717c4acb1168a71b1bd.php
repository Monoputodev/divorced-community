<?php
    $pages = App\Models\Page::where('tempname', $activeTemplate)
        ->where('is_default', Status::NO)
        ->get();
?>
<!-- Header -->

<!-- ==================== Bottom Header End Here ==================== -->
<header class="header-bottom">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(getFilePath('logoIcon') . '/logo.png')); ?>" alt=""></a>
            <button class="navbar-toggler header-button" data-bs-target="#navbarSupportedContent" data-bs-toggle="collapse" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="las la-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-menu ms-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(menuActive('home')); ?>" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(menuActive('packages')); ?>" href="<?php echo e(route('packages')); ?>"><?php echo app('translator')->get('Packages'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(menuActive('member.list')); ?>" href="<?php echo e(route('member.list')); ?>"><?php echo app('translator')->get('Members'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(menuActive('stories')); ?>" href="<?php echo e(route('stories')); ?>"><?php echo app('translator')->get('Stories'); ?></a>
                    </li>

                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php if(request()->url() == route('pages', [$page->slug])): ?> active <?php endif; ?>" href="<?php echo e(url($page->slug)); ?>"><?php echo e(__($page->name)); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(menuActive('contact')); ?>" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                    </li>
                    <li class="nav-item d-lg-none d-block">
                        <a class="nav-link <?php echo e(menuActive('user.home')); ?>" href="<?php echo e(route('user.login')); ?>">
                            <?php echo app('translator')->get('Dashboard'); ?></a>
                    </li>
                    <li class="nav-item d-lg-none d-block d-flex justify-content-between">
                        <a class="nav-link" href="<?php echo e(route('user.logout')); ?>"> <?php echo app('translator')->get('Logout'); ?></a>

                        <?php if($general->multi_language): ?>
                            <select class="langSel select language-select">
                                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lang->code); ?>" <?php if(session()->get('lang') == $lang->code): echo 'selected'; endif; ?>><?php echo app('translator')->get($lang->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </li>
                </ul>
                <div class="d-none d-lg-block">
                    <ul class="header-login list primary-menu">
                        <?php if($general->multi_language): ?>
                            <li class="header-login__item">
                                <select class="langSel select language-select">
                                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lang->code); ?>" <?php if(session()->get('lang') == $lang->code): echo 'selected'; endif; ?>><?php echo app('translator')->get($lang->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </li>
                        <?php endif; ?>
                        <li class="header-login__item">
                            <a class="btn btn--base btn--sm" href="<?php echo e(route('user.home')); ?>"> <i class="las la-user"></i> <?php echo app('translator')->get('Dashboard'); ?></a>
                        </li>

                        <li class="header-login__item">
                            <a class="btn btn--base btn--sm btn--outline" href="<?php echo e(route('user.logout')); ?>"> <?php echo app('translator')->get('Logout'); ?> </a>
                        </li>
                    </ul>
                </div>
                <!-- User Login End -->
            </div>
        </nav>
    </div>
</header>
<!-- ==================== Bottom Header End Here ==================== -->

<!-- =========================== Mobile Device Bottom Navigation Start ============================ -->
<div class="mobile-nav d-lg-none d-block">
    <div class="container">
        <ul class="mobile-nav__menu d-flex justify-content-between">
            <li class="mobile-nav__item">
                <a class="mobile-nav__link text-decoration-none" href="<?php echo e(route('user.home')); ?>">
                    <i class="las la-home"></i>
                    <span><?php echo app('translator')->get('Dashboard'); ?></span>
                </a>
            </li>

            <li class="mobile-nav__item">
                <a class="mobile-nav__link" href="<?php echo e(route('member.list')); ?>">
                    <i class="las la-users"></i>
                    <span><?php echo app('translator')->get('Members'); ?></span>
                </a>
            </li>

            <li class="mobile-nav__item">
                <a class="mobile-nav__link" href="<?php echo e(route('user.interest.requests')); ?>">
                    <i class="la la-heart-o"></i>
                    <span><?php echo app('translator')->get('Interest Request'); ?></span>
                </a>
            </li>

            <li class="mobile-nav__item dashboard-sidebar-show">
                <a class="mobile-nav__link" href="javascript:void(0)">
                    <i class="las la-bars"></i>
                    <span><?php echo app('translator')->get('Menu'); ?></span>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/partials/user_header.blade.php ENDPATH**/ ?>