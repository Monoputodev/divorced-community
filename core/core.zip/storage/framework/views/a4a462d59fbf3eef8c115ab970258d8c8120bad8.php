<!-- Report Modal -->
<div aria-hidden="true" class="modal custom--modal fade" id="reportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Report Member'); ?></h5>
                <button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"></button>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('user.report')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input name="complaint_id" type="hidden">
                        <div class="input--group">
                            <input class="form-control form--control" id="title" name="title" required type="text">
                            <label class="form--label" for="title"><?php echo app('translator')->get('Title'); ?></label>
                        </div>
                        <div class="input--group mt-3">
                            <textarea class="form-control form--control" id="reason" name="reason" required></textarea>
                            <label class="form--label" for="reason"><?php echo app('translator')->get('Reason'); ?></label>
                        </div>
                        <div class="input-group mt-3">
                            <div class="form--check">
                                <input <?php echo e(old('is_ignored') ? 'checked' : ''); ?> class="form-check-input" id="is_ignored" name="is_ignored" type="checkbox">
                                <label class="form-check-label" for="is_ignored"><?php echo app('translator')->get('Ignore this profile'); ?></label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn--base w-100" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </form>
            <?php else: ?>
                <div class="modal-body">
                    <p class="text-center"><?php echo app('translator')->get('Please login first'); ?></p>
                </div>
                <div class="modal-footer">
                    <a class="btn btn--dark" href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login'); ?></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/components/report-modal.blade.php ENDPATH**/ ?>