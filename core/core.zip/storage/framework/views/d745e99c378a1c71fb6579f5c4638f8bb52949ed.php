<?php
    $activePackages = \App\Models\Package::active();
    $packages = (clone $activePackages)
        ->orderBy('price', 'ASC')
        ->take(4)
        ->get();
    $totalPackage = $activePackages->count();
?>
<?php echo $__env->make($activeTemplate . 'partials.package', ['packages' => $packages, 'totalPackage' => $totalPackage], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/sections/package.blade.php ENDPATH**/ ?>