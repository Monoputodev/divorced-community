<?php $__env->startSection('content'); ?>
    <?php if($layout == 'frontend'): ?>
        <div class="section">
            <div class="container">
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card custom--card">
                <div class="card-header card-header-bg d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 mt-0">
                        <?php echo $myTicket->statusBadge; ?>
                        <span class="ticket-title">[<?php echo app('translator')->get('Ticket'); ?>#<?php echo e($myTicket->ticket); ?>] <?php echo e($myTicket->subject); ?></span>
                    </h6>
                    <?php if($myTicket->status != 3 && $myTicket->user): ?>
                        <button class="btn btn-danger close-button btn-sm confirmationBtn" data-action="<?php echo e(route('ticket.close', $myTicket->id)); ?>" data-question="<?php echo app('translator')->get('Are you sure to close this ticket?'); ?>" type="button"><i class="fa fa-lg fa-times-circle"></i>
                        </button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('ticket.reply', $myTicket->id)); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row gy-3">
                            <div class="col-12 form-group">
                                <div class="input--group">
                                    <textarea class="form-control form--control" name="message"><?php echo e(old('message')); ?></textarea>
                                    <label class="form--label"><?php echo app('translator')->get('Message'); ?></label>
                                </div>
                            </div>
                            <div class="form-group col-12">
                                <div class="text-end">
                                    <a class="btn btn--base btn-sm addFile" href="javascript:void(0)"><i class="fa fa-plus"></i> <?php echo app('translator')->get('Add New'); ?></a>
                                </div>
                                <div class="attachment-label"><label class="form-label text--dark"><?php echo app('translator')->get('Attachments'); ?></label> <small class="text-danger"><?php echo app('translator')->get('Max 5 files can be uploaded'); ?>. <?php echo app('translator')->get('Maximum upload size is'); ?> <?php echo e(ini_get('upload_max_filesize')); ?></small></div>
                                <input class="form-control form--control" name="attachments[]" type="file" />
                                <div id="fileUploadsContainer"></div>
                                <small class="ticket-attachments-message text-muted my-2">
                                    <?php echo app('translator')->get('Allowed File Extensions'); ?>: .<?php echo app('translator')->get('jpg'); ?>, .<?php echo app('translator')->get('jpeg'); ?>, .<?php echo app('translator')->get('png'); ?>, .<?php echo app('translator')->get('pdf'); ?>, .<?php echo app('translator')->get('doc'); ?>, .<?php echo app('translator')->get('docx'); ?>
                                </small>
                            </div>
                            <div class="form-group col-12">
                                <button class="btn btn--base w-100" type="submit"> <i class="fa fa-reply"></i> <?php echo app('translator')->get('Reply'); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-body">
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($message->admin_id == 0): ?>
                            <div class="row border-base border-radius-3 my-3 mx-2 border py-3">
                                <div class="col-md-3 border-end text-md-end">
                                    <h5 class="my-1"><?php echo e($message->ticket->name); ?></h5>
                                </div>
                                <div class="col-md-9">
                                    <p class="text-muted fw-bold my-1">
                                        <?php echo app('translator')->get('Posted on'); ?> <?php echo e($message->created_at->format('l, dS F Y @ H:i')); ?></p>
                                    <p><?php echo e($message->message); ?></p>
                                    <?php if($message->attachments->count() > 0): ?>
                                        <div class="mt-2">
                                            <?php $__currentLoopData = $message->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="mr-3" href="<?php echo e(route('ticket.download', encrypt($image->id))); ?>"><i class="fa fa-file"></i> <?php echo app('translator')->get('Attachment'); ?> <?php echo e(++$k); ?> </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row border-warning border-radius-3 my-3 mx-2 border py-3" style="background-color: #ffd96729">
                                <div class="col-md-3 border-end text-md-end">
                                    <h5 class="my-1"><?php echo e($message->admin->name); ?></h5>
                                    <p class="lead text-muted"><?php echo app('translator')->get('Staff'); ?></p>
                                </div>
                                <div class="col-md-9">
                                    <p class="text-muted fw-bold my-1">
                                        <?php echo app('translator')->get('Posted on'); ?> <?php echo e($message->created_at->format('l, dS F Y @ H:i')); ?></p>
                                    <p><?php echo e($message->message); ?></p>
                                    <?php if($message->attachments->count() > 0): ?>
                                        <div class="mt-2">
                                            <?php $__currentLoopData = $message->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="mr-3" href="<?php echo e(route('ticket.download', encrypt($image->id))); ?>"><i class="fa fa-file"></i> <?php echo app('translator')->get('Attachment'); ?> <?php echo e(++$k); ?> </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>

    <?php if($layout == 'frontend'): ?>
        </div>
        </div>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a class="btn btn-sm btn--base mb-2" href="<?php echo e(route('ticket.index')); ?>"> <i class="las la-ticket-alt"></i> <?php echo app('translator')->get('My Tickets'); ?></a>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
    <style>
        .input-group-text:focus {
            box-shadow: none !important;
        }

        .ticket-title {
            line-height: 1.5;
        }

        @media (max-width: 767px) {
            .attachment-label {
                padding: 10px 0px;
                line-height: 1.5;
            }

            .attachment-label label {
                margin-bottom: 0 !important;
            }

            .ticket-title {
                margin-top: 10px;
                font-size: 14px;
                display: block;
            }
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";
            var fileAdded = 0;
            $('.addFile').on('click', function() {
                if (fileAdded >= 4) {
                    notify('error', 'You\'ve added maximum number of file');
                    return false;
                }
                fileAdded++;
                $("#fileUploadsContainer").append(`
                    <div class="input-group my-3">
                        <input type="file" name="attachments[]" class="form-control form--control" required />
                        <button class="input-group-text btn-danger remove-btn"><i class="las la-times"></i></button>
                    </div>
                `)
            });
            $(document).on('click', '.remove-btn', function() {
                fileAdded--;
                $(this).closest('.input-group').remove();
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/support/view.blade.php ENDPATH**/ ?>