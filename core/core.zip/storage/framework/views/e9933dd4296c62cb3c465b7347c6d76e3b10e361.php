<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <!--Basic information-->
            <?php echo $__env->make($activeTemplate . 'user.profile_setting.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-12 mt-4">
            <!--Partner Expectation-->
            <?php echo $__env->make($activeTemplate . 'user.profile_setting.partner_expectation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-12 mt-4">
            <!--Physical attributes-->
            <?php echo $__env->make($activeTemplate . 'user.profile_setting.physical_attributes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-12 mt-4">
            <!--Family Info-->
            <?php echo $__env->make($activeTemplate . 'user.profile_setting.family', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-12 mt-4">
            <!--Career Info-->
            <?php echo $__env->make($activeTemplate . 'user.profile_setting.career', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-12 mt-4">
            <!--Education Info-->
            <?php echo $__env->make($activeTemplate . 'user.profile_setting.education', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/profile_setting/index.blade.php ENDPATH**/ ?>