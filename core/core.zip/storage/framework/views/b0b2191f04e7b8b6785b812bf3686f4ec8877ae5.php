<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php echo $__env->make($activeTemplate . 'partials.interest_table', ['interests' => $interests, 'pagination' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($interests->hasPages()): ?>
            <div class="mt-3 text-center">
                <?php echo e(paginateLinks($interests)); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="">
        <div class="input-group">
            <input class="form-control form--control bg-white" name="search" type="text" value="<?php echo e(request()->search); ?>">
            <button class="input-group-text btn btn--base" type="submit"><i class="las la-search"></i></button>
        </div>
    </form>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/interests.blade.php ENDPATH**/ ?>