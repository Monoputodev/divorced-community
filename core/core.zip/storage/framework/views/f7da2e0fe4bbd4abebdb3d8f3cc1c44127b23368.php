<?php $__env->startSection('content'); ?>
    <div class="table-responsive--md">
        <table class="custom--table table">
            <?php if(count($purchasedPackages)): ?>
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('Package'); ?></th>
                        <th><?php echo app('translator')->get('Validity Period'); ?></th>
                        <th><?php echo app('translator')->get('Price'); ?></th>
                        <th><?php echo app('translator')->get('Purchase Date'); ?></th>
                        <th><?php echo app('translator')->get('Status'); ?></th>
                        <th><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                </thead>
            <?php endif; ?>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $purchasedPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchasedPackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <h6 class="user__text mt-0 mb-0"> <?php echo e($purchasedPackage->package_details->name); ?></h6>
                        </td>
                        <td>
                            <?php if($purchasedPackage->package_details->validity_period > -1): ?>
                                <?php echo e($purchasedPackage->package_details->validity_period); ?>

                            <?php else: ?>
                                <?php echo app('translator')->get('Unlimited'); ?>
                            <?php endif; ?>
                            <?php echo app('translator')->get('Days'); ?>
                        </td>
                        <td>
                            <?php echo e(showAmount($purchasedPackage->package_details->price)); ?> <?php echo e(__($general->cur_text)); ?>

                        </td>
                        <td><?php echo e(showDateTime($purchasedPackage->created_at, 'd M, Y')); ?></td>
                        <td><?php echo $purchasedPackage->statusBadge ?></td>
                        <td>
                            <button class="btn btn--icon btn--base detailBtn" data-deposit="<?php echo e($purchasedPackage->deposit); ?>" data-package_details="<?php echo e(json_encode($purchasedPackage->package_details)); ?>"><i class="las la-desktop"></i></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="100">
                            <div class="empty-table text-center">
                                <div class="empty-table__icon">
                                    <i class="las la-frown"></i>
                                </div>
                                <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?></h6>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if($purchasedPackages->hasPages()): ?>
            <div class="mt-3 text-center">
                <?php echo e(paginateLinks($purchasedPackages)); ?>

            </div>
        <?php endif; ?>
    </div>

    <div aria-hidden="true" class="modal custom--modal fade" id="detailModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Purchase Details!'); ?></h5>
                    <button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"></button>
                </div>
                <div class="modal-body">
                    <ul class="list-group list-group-flush payment-details">
                        <li class="list-group-item d-flex justify-content-between flex-wrap gap-2">
                            <small class="fw-bold"><?php echo app('translator')->get('Package'); ?></small>
                            <small class="package-name fw-bold"></small>
                        </li>
                        <li class="list-group-item d-flex justify-content-between flex-wrap gap-2">
                            <small class="fw-bold"><?php echo app('translator')->get('Interest express limit'); ?></small>
                            <small class="interest-express"></small>
                        </li>
                        <li class="list-group-item d-flex justify-content-between flex-wrap gap-2">
                            <small class="fw-bold"><?php echo app('translator')->get('Contact view limit'); ?></small>
                            <small class="contact-view"></small>
                        </li>
                        <li class="list-group-item d-flex justify-content-between flex-wrap gap-2">
                            <small class="fw-bold"><?php echo app('translator')->get('Image upload limit'); ?></small>
                            <small class="image-upload"></small>
                        </li>
                        <li class="list-group-item d-flex justify-content-between flex-wrap gap-2">
                            <small class="fw-bold"><?php echo app('translator')->get('Validity Period'); ?></small>
                            <small class="validity-period fw-bold"></small>
                        </li>
                        <li class="list-group-item d-flex justify-content-between flex-wrap gap-2 ">
                            <small class="fw-bold"><?php echo app('translator')->get('Payment Via'); ?></small>
                            <small class="payment-via"></small>
                        </li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button class="btn btn--dark btn--sm" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="">
        <div class="input-group">
            <input class="form-control form--control bg-white" name="search" type="text" value="<?php echo e(request()->search); ?>">
            <button class="input-group-text btn btn--base" type="submit"><i class="las la-search"></i></button>
        </div>
    </form>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            $('.detailBtn').on('click', function() {
                let packageDetail = $(this).data('package_details');
                let deposit = $(this).data('deposit');
                let modal = $('#detailModal');
                modal.find('.package-name').text(packageDetail.name)
                modal.find('.interest-express').text(parseInt(packageDetail.interest_express_limit) > -1 ? packageDetail.interest_express_limit : `<?php echo app('translator')->get('Unlimited'); ?>`)
                modal.find('.contact-view').text(parseInt(packageDetail.contact_view_limit) > -1 ? packageDetail.contact_view_limit : `<?php echo app('translator')->get('Unlimited'); ?>`)
                modal.find('.image-upload').text(parseInt(packageDetail.image_upload_limit) > -1 ? packageDetail.image_upload_limit : `<?php echo app('translator')->get('unlimited'); ?>`)
                modal.find('.validity-period').text(parseInt(packageDetail.validity_period) > -1 ? packageDetail.validity_period + ` <?php echo app('translator')->get('days'); ?>` : `<?php echo app('translator')->get('Unlimited'); ?>`)
                modal.find('.payment-via').text(deposit.gateway.name);
                if (deposit.method_code >= 1000) {
                    let ul = modal.find('.payment-details');
                    if (deposit.detail != null && deposit.detail.length > 0) {
                        $.each(deposit.detail, function(i, element) {
                            if (element.type != 'file') {
                                ul.append(`
                                   <li class="list-group-item d-flex justify-content-between flex-wrap gap-2 manual-payment">
                                       <small class="fw-bold">${element.name}</small>
                                       <small class="validity-period fw-bold">${element.value}</small>
                                   </li>
                               `);
                            }
                        });
                    }
                } else {
                    $(document).find('.manual-payment').remove();
                }

                modal.modal('show');
            })
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/user/purchase_history.blade.php ENDPATH**/ ?>