<?php
    $user = auth()
        ->user()
        ->load('interestRequests');
    $pendingInterestRequestCount = $user->interestRequests->where('status', Status::NO)->count();
    $unseenMessageCount = App\Models\Message::where('receiver_id', $user->id)
        ->where('read_status', Status::NO)
        ->count();
?>

<div class="col-lg-4 col-xl-3">
    <div class="dashboard-sidenav">
        <div class="dashboard-sidenav__close d-lg-none d-block">
            <button class="dashboard-sidenav__close-icon" type="button"><i class="las la-times"></i></button>
        </div>
        <div class="dashboard-profile">
            <div class="team-card" style="width: 100%; display: inline-block;">
                <div class="team-card__img mx-auto">
                    <img class="team-card__img-is" src="<?php echo e(getImage(getFilePath('userProfile') . '/' . $user->image, getFileSize('userProfile'), 'user')); ?>" alt="<?php echo app('translator')->get('Profile Image'); ?>">
                    <button class="profile-picture" type="button"><i class="las la-pencil-alt"></i></button>
                </div>

                <div class="team-card__body text-center">
                    <h5 class="dashboard-profile__name team-card__body-name mb-0"><?php echo e($user->fullname); ?></h5>
                    <h6 class="dashboard-profile__id team-card__body-id my-2"> <?php echo app('translator')->get('ID'); ?> :
                        <?php echo e($user->profile_id); ?> </h6>
                    <a class="btn btn--light-bg sm-text fw-md w-100 mt-2" href="<?php echo e(route('user.member.profile.public', $user->id)); ?>"><?php echo app('translator')->get('Public Profile'); ?></a>
                </div>
            </div>

        </div>
        <nav class="dashboard-menu">
            <ul class="list menu-item" style="--gap: 0;">
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.home')); ?>" href="<?php echo e(route('user.home')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-layer-group"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Dashboard'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.purchase.history')); ?>" href="<?php echo e(route('user.purchase.history')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-cog"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Purchase History'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.gallery')); ?>" href="<?php echo e(route('user.gallery')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-image"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Gallery'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.shortlist')); ?>" href="<?php echo e(route('user.shortlist')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-list"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Shortlist'); ?> </span>
                    </a>
                </li>

                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.interest.list')); ?>" href="<?php echo e(route('user.interest.list')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="la la-heart-o"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('My Interest'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.interest.requests')); ?>" href="<?php echo e(route('user.interest.requests')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="la la-heart-o"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Interest Request'); ?> </span>
                        <?php if($pendingInterestRequestCount): ?>
                            <span class="dashboard-menu__noti"><?php echo e($pendingInterestRequestCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.ignored.list')); ?>" href="<?php echo e(route('user.ignored.list')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-ban"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Ignored Lists'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.message.index')); ?>" href="<?php echo e(route('user.message.index')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-envelope"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Message'); ?> </span>
                        <?php if($unseenMessageCount): ?>
                            <span class="dashboard-menu__noti"> <?php echo e($unseenMessageCount); ?> </span>
                        <?php endif; ?>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('ticket.*')); ?>" href="<?php echo e(route('ticket.index')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-ticket-alt"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Support Tickets'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.profile.setting')); ?>" href="<?php echo e(route('user.profile.setting')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-user"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Profile Setting'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link <?php echo e(menuActive('user.change.password')); ?>" href="<?php echo e(route('user.change.password')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-key"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Change Password'); ?> </span>
                    </a>
                </li>
                <li>
                    <a class="t-link dashboard-menu__link" href="<?php echo e(route('user.logout')); ?>">
                        <span class="dashboard-menu__icon">
                            <i class="las la-sign-out-alt"></i>
                        </span>
                        <span class="dashboard-menu__text"> <?php echo app('translator')->get('Sign Out'); ?> </span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<!-- Report Modal -->
<div class="modal custom--modal fade" id="profilePictureModal" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Change Profile Picture'); ?></h5>
                <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('user.profile.picture.update')); ?>" enctype="multipart/form-data" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="mb-2"><?php echo app('translator')->get('Profile Picture'); ?></label>
                        <div class="image-upload">
                            <div class="image-upload">
                                <div class="thumb">
                                    <div class="avatar-preview">
                                        <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage(getFilePath('userProfile') . '/' . $user->image, getFileSize('userProfile'))); ?>)">
                                            <button class="remove-image" type="button"><i class="fa fa-times"></i></button>
                                        </div>
                                    </div>
                                    <div class="avatar-edit">
                                        <input class="profilePicUpload" id="profilePicUpload1" name="image" type="file" accept=".png, .jpg, .jpeg">
                                        <label class="bg--dark text-white" for="profilePicUpload1"><?php echo app('translator')->get('Upload Image'); ?></label>
                                        <small class="mt-2"><?php echo app('translator')->get('Supported files'); ?>: <b><?php echo app('translator')->get('jpeg'); ?>, <?php echo app('translator')->get('jpg'); ?>,, <?php echo app('translator')->get('png'); ?>.</b> <?php echo app('translator')->get('Image will be resized into '); ?><?php echo e(getFileSize('userProfile')); ?><?php echo app('translator')->get('px'); ?> </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn--base w-100" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .profile-picture {
            border: 0;
            background-color: #f114ab;
            color: #fff;
            border-radius: 50%;
            padding: 2px 6px;
            position: absolute;
            right: 0;
            bottom: 0;
            outline: 2px solid #fff;
        }

        .profile-picture:focus {
            outline: 2px solid #fff !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/partials/sidenav.blade.php ENDPATH**/ ?>