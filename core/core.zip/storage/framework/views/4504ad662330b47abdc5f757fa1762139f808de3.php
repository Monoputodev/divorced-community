<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?>
<?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>