<?php $__env->startSection('content'); ?>
    <div class="section--sm section--top bg--light">
        <div class="container">
            <div class="row g-4 justify-content-center">

                <div class="col-md-4">
                    <div class="contact-card">
                        <div class="contact-card__icon-container text-center">
                            <div class="contact-card__icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                        </div>
                        <div class="contact-card__body">
                            <h5 class="mt-md-0"><?php echo e(__(@$contactContent->data_values->office_address_title)); ?></h5>
                            <p><?php echo e(__(@$contactContent->data_values->office)); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="contact-card">
                        <div class="contact-card__icon-container text-center">
                            <div class="contact-card__icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                        </div>
                        <div class="contact-card__body">
                            <h5 class="mt-md-0"><?php echo e(__(@$contactContent->data_values->email_address_title)); ?></h5>
                            <a href="mailto:<?php echo e(@$contactContent->data_values->email); ?>"><?php echo e(__(@$contactContent->data_values->email)); ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="contact-card">
                        <div class="contact-card__icon-container text-center">
                            <div class="contact-card__icon">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                        </div>
                        <div class="contact-card__body">
                            <h5 class="mt-md-0"><?php echo e(__(@$contactContent->data_values->contact_number_title)); ?></h5>
                            <a href="tel:<?php echo e(@$contactContent->data_values->contact_number); ?>"><?php echo e(__(@$contactContent->data_values->contact_number)); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section--sm section--bottom bg-light">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="contact-form">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <h3 class="form-title mt-0"><?php echo e(@$contactContent->data_values->title); ?></h3>
                            </div>
                            <form class="verify-gcaptcha" action="" autocomplete="off" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-12 <?php if(auth()->guard()->check()): ?> d-none <?php endif; ?> mt-4">
                                        <div class="input--group">
                                            <input class="form-control form--control" id="name" name="name" type="text" value="<?php echo e(auth()->user() ? auth()->user()->fullname : old('name')); ?>" <?php if(auth()->user()): ?> readonly <?php endif; ?> required placeholder=" ">
                                            <label class="form--label" for="name"><?php echo app('translator')->get('Name'); ?></label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 <?php if(auth()->guard()->check()): ?> d-none <?php endif; ?> mt-4">
                                        <div class="input--group">
                                            <input class="form-control form--control" id="email" name="email" type="email" value="<?php echo e(auth()->user() ? auth()->user()->email : old('email')); ?>" <?php if(auth()->user()): ?> readonly <?php endif; ?> required>
                                            <label class="form--label" for="email"><?php echo app('translator')->get('Email Address'); ?></label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 mt-4">
                                        <div class="input--group">
                                            <input class="form-control form--control" id="subject" name="subject" type="text" value="<?php echo e(old('subject')); ?>" required>
                                            <label class="form--label" for="subject"><?php echo app('translator')->get('Subject'); ?></label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 mt-4">
                                        <div class="input--group">
                                            <textarea class="form-control form--control" id="message" name="message" required><?php echo e(old('message')); ?></textarea>
                                            <label class="form--label" for="message"><?php echo app('translator')->get('Message'); ?></label>
                                        </div>
                                    </div>

                                    <?php if (isset($component)) { $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243 = $component; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Captcha::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243)): ?>
<?php $component = $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243; ?>
<?php unset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243); ?>
<?php endif; ?>

                                    <div class="col-sm-12">
                                        <button class="btn btn--base w-100 mt-3" type="submit"><?php echo e(__(@$contactContent->data_values->button_text)); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="contact-img">
                        <img class="contact-img__is" src="<?php echo e(getImage('assets/images/frontend/contact_us/' . @$contactContent->data_values->image, '800x550')); ?>" alt="<?php echo app('translator')->get('Contact Us'); ?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if($sections != null): ?>
        <?php $__currentLoopData = json_decode($sections); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate . 'sections.' . $sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matrimonial\core\resources\views/templates/basic/contact.blade.php ENDPATH**/ ?>