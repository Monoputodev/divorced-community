<?php $__env->startSection('content'); ?>
    <!-- Dashboard  -->
    <div class="section bg-light">
        <div class="container">
            <div class="row gy-4 justify-content-center">
                <div class="col-xxl-3 col-lg-4 col-md-8">
                    <div class="profile-sidebar">
                        <div class="row gy-4">
                            <div class="col-sm-12">
                                <div class="public-profile">
                                    <div class="team-card border-0" style="width: 100%; display: inline-block;">
                                        <div class="team-card__img mx-auto">
                                            <img class="team-card__img-is" src="<?php echo e(getImage(getFilePath('userProfile') . '/' . $member->image)); ?>" alt="<?php echo app('translator')->get('Profile Image'); ?>">
                                        </div>
                                        <div class="team-card__body p-3 text-start">
                                            <div class="profile-name-interest d-flex align-items-center justify-content-between flex-wrap">
                                                <div class="profile-name">
                                                    <h5 class="dashboard-profile__name team-card__body-name mb-0 mt-0">
                                                        <?php echo e($member->fullname); ?></h5>
                                                    <h6 class="dashboard-profile__id team-card__body-id my-2">
                                                        <?php echo app('translator')->get('ID'); ?> :
                                                        <?php echo e($member->profile_id); ?> </h6>
                                                </div>

                                                <div class="profile-interest text-center">
                                                    <?php if($user->interests->where('interesting_id', $member->id)->first()): ?>
                                                        <a class="profile-interest-love base-color" href="javascript:void(0)">
                                                            <i class="fas fa-heart"></i> <span class="f-13"><?php echo app('translator')->get('Interest Expressed'); ?></span>
                                                        </a>
                                                    <?php elseif($member->interests->where('interesting_id', $user->id)->where('status', 0)->first()): ?>
                                                        <a class="profile-interest-love base-color" href="#">
                                                            <i class="fas fa-heart"></i> <span class="f-13"><?php echo app('translator')->get('Response to Interest'); ?></span>
                                                        </a>
                                                    <?php elseif($member->interests->where('interesting_id', $user->id)->where('status', 1)->first()): ?>
                                                        <a class="profile-interest-love base-color" href="#">
                                                            <i class="fas fa-heart"></i> <span class="f-13"><?php echo app('translator')->get('You Accepted Interest'); ?></span>
                                                        </a>
                                                    <?php elseif($member->id == $user->id): ?>
                                                        <a class="profile-interest-love" href="javascript:void(0)">
                                                            <i class="fas fa-heart"></i> <span class="f-13"><?php echo app('translator')->get('Interest'); ?></span>
                                                        </a>
                                                    <?php else: ?>
                                                        <a class="profile-interest-love interestExpressBtn" data-interesting_id="<?php echo e($member->id); ?>" href="javascript:void(0)">
                                                            <i class="fas fa-heart"></i> <span class="f-13"><?php echo app('translator')->get('Interest'); ?></span>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="search__right-details">
                                                <div class="row profile-banner__left-detiails member-details">
                                                    <label class="col-6">
                                                        <i class="la la-ring"></i>
                                                        <span><?php echo app('translator')->get('Marital Status'); ?></span>
                                                    </label>
                                                    <span class="col-6">
                                                        <?php echo e(__(@$member->basicInfo->marital_status ?? 'N/A')); ?>

                                                    </span>
                                                </div>

                                                <div class="row profile-banner__left-detiails member-details">
                                                    <label class="col-6"><i class="las la-search"></i>
                                                        <span><?php echo app('translator')->get('Looking For'); ?></span>
                                                    </label>
                                                    <span class="col-6">
                                                        <?php if($member->looking_for == 1): ?>
                                                            <?php echo app('translator')->get('Male'); ?>
                                                        <?php elseif($member->looking_for == 2): ?>
                                                            <?php echo app('translator')->get('Female'); ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                                <div class="row profile-banner__left-detiails member-details">
                                                    <label class="col-6">
                                                        <i class="las la-flag"></i>
                                                        <span><?php echo app('translator')->get('Country'); ?></span>
                                                    </label>
                                                    <span class="col-6">
                                                        <?php echo e(__(@$member->basicInfo->present_address->country)); ?>

                                                    </span>
                                                </div>
                                            </div>
                                            <div class="search__right-expression">
                                                <ul class="row search__right-list m-0">
                                                    <li class="col-4 profile-item">
                                                        <?php if($user->shortListedProfile->where('profile_id', $member->id)->first()): ?>
                                                            <a class="removeFromShortList base-color" data-action="<?php echo e(route('user.remove.short.list')); ?>" data-profile_id="<?php echo e($member->id); ?>" href="javascript:void(0)">
                                                                <i class="far fa-star"></i><?php echo app('translator')->get('Shortlisted'); ?>
                                                            </a>
                                                        <?php elseif($member->id == $user->id): ?>
                                                            <a href="javascript:void(0)">
                                                                <i class="far fa-star"></i><?php echo app('translator')->get('Shortlist'); ?>
                                                            </a>
                                                        <?php else: ?>
                                                            <a class="addToShortList" data-action="<?php echo e(route('user.add.short.list')); ?>" data-profile_id="<?php echo e($member->id); ?>" href="javascript:void(0)">
                                                                <i class="far fa-star"></i><?php echo app('translator')->get('Shortlist'); ?>
                                                            </a>
                                                        <?php endif; ?>
                                                    </li>
                                                    <li class="col-4 profile-item">
                                                        <?php if($member->id == $user->id): ?>
                                                            <a href="javascript:void(0)">
                                                                <i class="fas fa-ban"></i><?php echo app('translator')->get('Ignore'); ?>
                                                            </a>
                                                        <?php else: ?>
                                                            <a class="confirmationBtn" data-action="<?php echo e(route('user.ignore', $member->id)); ?>" data-question="<?php echo app('translator')->get('Are you sure, you want to ignore this member?'); ?>" href="javascript:void(0)">
                                                                <i class="fas fa-ban"></i><?php echo app('translator')->get('Ignore'); ?>
                                                            </a>
                                                        <?php endif; ?>
                                                    </li>
                                                    <li class="col-4 profile-item">
                                                        <?php
                                                            $report = $user->reports->where('complaint_id', $member->id)->first();
                                                        ?>
                                                        <?php if($report): ?>
                                                            <a class="text--danger reportedUser" data-report_reason="<?php echo e(__($report->reason)); ?>" data-report_title="<?php echo e(__($report->title)); ?>" href="javascript:void(0)">
                                                                <i class="fas fa-info-circle"></i><?php echo app('translator')->get('Reported'); ?>
                                                            </a>
                                                        <?php elseif($member->id == $user->id): ?>
                                                            <a href="javascript:void(0)">
                                                                <i class="fas fa-info-circle"></i><?php echo app('translator')->get('Report'); ?>
                                                            </a>
                                                        <?php else: ?>
                                                            <a href="javascript:void(0)" onclick="showReportModal(<?php echo e($member->id); ?>)">
                                                                <i class="fas fa-info-circle"></i><?php echo app('translator')->get('Report'); ?>
                                                            </a>
                                                        <?php endif; ?>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-9 col-lg-8">
                    <ul class="nav nav-pills custom--tabs mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="member-details-tab" data-bs-target="#member-detail" data-bs-toggle="pill" type="button" role="tab" aria-controls="member-detail" aria-selected="true"><i class="far fa-user-circle"></i> <?php echo app('translator')->get('Detailed Profile'); ?></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="partnerExpectation-tab" data-bs-target="#partnerExpectation" data-bs-toggle="pill" type="button" role="tab" aria-controls="partnerExpectation" aria-selected="false"> <i class="fas fa-chart-line"></i>
                                <?php echo app('translator')->get('Partner Preference'); ?></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-contact-tab" data-bs-target="#pills-contact" data-bs-toggle="pill" type="button" role="tab" aria-controls="pills-contact" aria-selected="false"><i class="far fa-image"></i> <?php echo app('translator')->get('Photo Gallery'); ?></button>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="member-detail" role="tabpanel" aria-labelledby="member-details-tab">
                            <div class="public-profile__accordion accordion custom--accordion" id="accordionPanelsStayOpenExample">

                                <!-- Basic information -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="panelsStayOpen-basicInfo">
                                        <button class="accordion-button" data-bs-target="#panelsStayOpen-collapseBasicInfo" data-bs-toggle="collapse" type="button" aria-controls="panelsStayOpen-collapseBasicInfo" aria-expanded="true">
                                            <?php echo app('translator')->get('Basic Information'); ?>
                                        </button>
                                    </h2>
                                    <div class="accordion-collapse collapse show" id="panelsStayOpen-collapseBasicInfo" aria-labelledby="panelsStayOpen-basicInfo">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <?php echo $__env->make($activeTemplate . 'user.members.basic_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Basic information end-->

                                <?php if($user->id != $member->id): ?>
                                    <!-- Contact Details -->
                                    <div class="accordion-item">
                                        <?php
                                            $exist = $user->contacts->where('contact_id', $member->id)->first();
                                        ?>

                                        <h2 class="accordion-header" id="panelsStayOpen-contactDetails">
                                            <button class="accordion-button contact-detail <?php if(!$exist): ?> collapsed <?php endif; ?>" data-bs-target="#panelsStayOpen-collapseContactDetails" data-permit="<?php echo e($exist ? 1 : 0); ?>" type="button" aria-controls="panelsStayOpen-collapseContactDetails" aria-expanded="<?php echo e($exist ? 'true' : 'false'); ?>" <?php if($exist): ?> data-bs-toggle="collapse" <?php endif; ?>>
                                                <?php echo app('translator')->get('Contact Details'); ?>
                                            </button>
                                        </h2>
                                        <div class="accordion-collapse collapse <?php if($exist): ?> show <?php endif; ?>" id="panelsStayOpen-collapseContactDetails" aria-labelledby="panelsStayOpen-contactDetails">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="d-flex flex-wrap">
                                                            <i class="las la-phone mt-1"></i>
                                                            <?php if($exist): ?>
                                                                <span class="ps-2"><?php echo e($member->mobile); ?></span>
                                                            <?php else: ?>
                                                                <span class="ps-2">xxxxxxxxxxxxxxxxxx</span>
                                                            <?php endif; ?>
                                                        </div>

                                                        <div class="d-flex flex-wrap">
                                                            <i class="las la-envelope mt-1"></i>
                                                            <?php if($exist): ?>
                                                                <span class="ps-2"><?php echo e($member->email); ?></span>
                                                            <?php else: ?>
                                                                <span class="ps-2">xxxxxxxxxxxxxxxxxx</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Contact Details end-->
                                <?php endif; ?>

                                <!-- Education Info-->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="panelsStayOpen-eduInfo">
                                        <button class="accordion-button" data-bs-target="#panelsStayOpen-collapseEduInfo" data-bs-toggle="collapse" type="button" aria-controls="panelsStayOpen-collapseEduInfo" aria-expanded="true">
                                            <?php echo app('translator')->get('Education Information'); ?>
                                        </button>
                                    </h2>
                                    <div class="accordion-collapse collapse show" id="panelsStayOpen-collapseEduInfo" aria-labelledby="panelsStayOpen-eduInfo">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php if($member->educationInfo->count()): ?>
                                                        <?php $__currentLoopData = $member->educationInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="information-item">
                                                                <h6 class="information-item__title mb-2"><?php echo e(__($education->institute)); ?></h6>
                                                                <div class="information-item__content">
                                                                    <p class="information-item__desc bold mb-0"><?php echo e(__($education->degree)); ?>,
                                                                        <?php echo e(__($education->field_of_study)); ?></p>
                                                                    <?php if($education->end): ?>
                                                                        <p class="information-item__desc mb-0"><?php echo e($education->result); ?> (<?php echo app('translator')->get('Out of - '); ?>
                                                                            <?php echo e($education->out_of); ?>)</p>
                                                                        <p class="information-item__desc mb-0"><?php echo app('translator')->get('Roll No'); ?> :
                                                                            <?php echo e($education->roll_no); ?>, <?php echo app('translator')->get('Registration No'); ?>
                                                                            : <?php echo e($education->reg_no); ?></p>
                                                                        <p class="information-item__desc mb-0"><?php echo e($education->start); ?> -
                                                                            <?php echo e($education->end); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="information-item__desc mb-0"><?php echo app('translator')->get('Running'); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <div class="empty-table text-center">
                                                            <div class="empty-table__icon">
                                                                <i class="las la-frown"></i>
                                                            </div>
                                                            <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?>

                                                            </h6>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Education Info end -->

                                <!-- Career Info-->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="panelsStayOpen-careerInfo">
                                        <button class="accordion-button" data-bs-target="#panelsStayOpen-collapseCareerInfo" data-bs-toggle="collapse" type="button" aria-controls="panelsStayOpen-collapseCareerInfo" aria-expanded="true">
                                            <?php echo app('translator')->get('Career Information'); ?>
                                        </button>
                                    </h2>
                                    <div class="accordion-collapse collapse show" id="panelsStayOpen-collapseCareerInfo" aria-labelledby="panelsStayOpen-careerInfo">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php if($member->careerInfo->count()): ?>
                                                        <?php $__currentLoopData = $member->careerInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <h6 class="information-item__title mb-2"><?php echo e(__($career->designation)); ?></h6>
                                                                    <p class="information-item__desc mb-0"><?php echo e(__($career->company)); ?></p>
                                                                    <?php if($career->end): ?>
                                                                        <p class="information-item__desc mb-0"><?php echo e($education->start); ?> -
                                                                            <?php echo e($education->end); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="information-item__desc mb-0"><?php echo app('translator')->get('Running'); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <div class="empty-table text-center">
                                                            <div class="empty-table__icon">
                                                                <i class="las la-frown"></i>
                                                            </div>
                                                            <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?>

                                                            </h6>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Career Info end -->
                            </div>
                        </div>

                        <div class="tab-pane fade" id="partnerExpectation" role="tabpanel" aria-labelledby="partnerExpectation-tab">
                            <div class="card custom--card">
                                <div class="card-body">
                                    <div class="row">
                                        <?php echo $__env->make($activeTemplate . 'user.members.partner_expectation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                            <div class="row gy-4">
                                <?php if($member->galleries->count()): ?>
                                    <?php $__currentLoopData = $member->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="profile-gallery">
                                                <div class="profile-gallery__thumb">
                                                    <img src="<?php echo e(getImage(getFilePath('gallery') . '/' . $gallery->image)); ?>" /></a>
                                                    <div class="profile-gallery__icon">
                                                        <a class="magnific-gallery" href="<?php echo e(getImage(getFilePath('gallery') . '/' . $gallery->image)); ?>"><i class="fas fa-search-plus"></i> </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="col-12">
                                        <div class="card custom--card">
                                            <div class="empty-table text-center">
                                                <div class="empty-table__icon">
                                                    <i class="las la-frown"></i>
                                                </div>
                                                <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?>

                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal custom--modal fade" id="contactDetailModal" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Confirm Contact View'); ?></h5>
                    <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('user.contact.view')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="modal-body">
                        <input name="contact_id" type="hidden">
                        <?php if(checkValidityPeriod($user->limitation) && ($user->limitation->contact_view_limit == -1 || $user->limitation->contact_view_limit)): ?>
                            <div class="text-center">
                                <p class="fw-bold"><?php echo app('translator')->get('Remaining Contact View'); ?> : <span class="remainingContactView"></span> <?php echo app('translator')->get(' times'); ?></p>
                                <?php if($user->limitation->contact_view_limit != -1): ?>
                                    <small class="text--danger">**<?php echo app('translator')->get('N.B. Viewing this members contact information will cost 1 from your remaining contact view'); ?>**</small>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center">
                                <?php if(!checkValidityPeriod($user->limitation)): ?>
                                    <p class="fw-bold"><?php echo app('translator')->get('Your package has been expired'); ?> <span class="fw-600"><?php echo e(diffForHumans($user->limitation->expire_date)); ?></span></p>
                                <?php else: ?>
                                    <p class="fw-bold"><?php echo app('translator')->get('Remaining Express Interest'); ?> : <span class="remainingContactView"></span></p>
                                <?php endif; ?>
                                <?php if($general->default_package_id): ?>
                                    <small><?php echo app('translator')->get('Purchase package from '); ?>
                                        <a class="text--base" href="<?php echo e(route('packages')); ?>"><?php echo app('translator')->get('packages'); ?></a>
                                    </small>
                                <?php else: ?>
                                    <small class="text--danger">
                                        <?php echo app('translator')->get('Viewing contact will charge '); ?> <span class="fw-600"><?php echo e(@$general->global_package->contact_view_charge); ?> <?php echo e(__($general->cur_text)); ?></span>
                                        <?php echo app('translator')->get('from your balance.'); ?>
                                    </small>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <?php if(checkValidityPeriod($user->limitation) && ($user->limitation->contact_view_limit == -1 || $user->limitation->contact_view_limit)): ?>
                            <button class="btn btn--base w-100" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                        <?php else: ?>
                            <button class="btn btn--dark btn-sm" data-bs-dismiss="modal" type="button"><?php echo app('translator')->get('Close'); ?></button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('report-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-show-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('report-show-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b = $component; } ?>
<?php $component = App\View\Components\InterestExpressModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('interest-express-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InterestExpressModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b)): ?>
<?php $component = $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b; ?>
<?php unset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";

        let config = {
            routes: {
                addShortList: "<?php echo e(route('user.add.short.list')); ?>",
                removeShortList: "<?php echo e(route('user.remove.short.list')); ?>",
            },
            loadingText: {
                addShortList: "<?php echo e(trans('Shortlisting')); ?>",
                removeShortList: "<?php echo e(trans('Removing')); ?>",
                interestExpress: "<?php echo e(trans('Processing')); ?>",
            },
            buttonText: {
                addShortList: "<?php echo e(trans('Shortlist')); ?>",
                removeShortList: "<?php echo e(trans('Shortlisted')); ?>",
                interestExpressed: "<?php echo e(trans('Interest Expressed')); ?>",
                expressInterest: "<?php echo e(trans('Interest')); ?>",
            }
        }

        $('.express-interest-form').on('submit', function(e) {
            e.preventDefault();

            let formData = new FormData(this);
            let url = $(this).attr('action');
            let modal = $('#interestExpressModal');
            let id = modal.find('[name=interesting_id]').val();
            let container = $('.profile-interest');
            $.ajax({
                type: "post",
                url: url,
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $(container).find('a').html(` <i class="fas fa-heart"></i> <span class="f-13">${config.loadingText.interestExpress}..</span>`);
                },
                success: function(response) {
                    modal.modal('hide');
                    if (response.success) {
                        notify('success', response.success);
                        container.find('a').remove();
                        container.html(`<a href="javascript:void(0)" class="profile-interest-love base-color">
                                <i class="fas fa-heart"></i><span class="f-13">${config.buttonText.interestExpressed}</span></a>
                        `);
                    } else {
                        notify('error', response.error);
                        container.html(`
                            <a href="javascript:void(0)" class="profile-interest-love interestExpressBtn" data-interesting_id="${id}">
                                <i class="fas fa-heart"></i><span class="f-13">${config.buttonText.expressInterest}</span>
                            </a>
                        `);
                    }
                }
            });
        });

        //contact view
        let contactDetailBtn = $('.contact-detail');
        contactDetailBtn.on('click', function() {
            let permission = parseInt($(this).data('permit'));

            if (!permission) {
                let modal = $('#contactDetailModal');
                let route = "<?php echo e(route('user.contact.limit')); ?>";
                let contactId = "<?php echo e($member->id); ?>";
                modal.find('[name=contact_id]').val(contactId);
                $.get(route,
                    function(data) {
                        if (data == '-1') {
                            modal.find('.remainingContactView').text('Unlimited');
                        } else
                            modal.find('.remainingContactView').text(data);
                    }
                );
                modal.modal('show');
            }
        });
    </script>
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/member.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/members/profile.blade.php ENDPATH**/ ?>