<?php $__env->startSection('content'); ?>
    <!-- Search Result  -->
    <div class="section search">
        <div class="container">
            <div class="row g-4">
                <div class="col-xl-3 d-xl-block">
                    <div class="search__left">
                        <div class="search__left-btn d-xl-none d-block">
                            <i class="las la-times"></i>
                        </div>
                        <form class="form-search" action="<?php echo e(route('member.list')); ?>" autocomplete="off">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="search__left-title">
                                        <h5 class="text mt-0 mb-0"><?php echo app('translator')->get('Member Filter'); ?> </h5>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <input class="form-control form--control" id="member-id" name="member_id" type="text">
                                        <label class="form--label" for="member-id"><?php echo app('translator')->get('Member ID'); ?></label>
                                    </div>
                                </div>

                                <div class="col-md-12 mt-4">
                                    <div class="range-slider">
                                        <p>
                                            <label class="range-slider__label" for="height"><?php echo app('translator')->get('Height'); ?>:</label>
                                            <input class="range-slider__number" id="height" name="height" type="text" readonly>
                                        </p>
                                        <div id="slider-range"></div>
                                    </div>
                                </div>

                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <select class="form-control form--control" name="looking_for">
                                            <option value=""><?php echo app('translator')->get('All'); ?></option>
                                            <option value="1" <?php if(request()->looking_for == 1): echo 'selected'; endif; ?>><?php echo app('translator')->get('Bridgroom'); ?></option>
                                            <option value="2" <?php if(request()->looking_for == 2): echo 'selected'; endif; ?>><?php echo app('translator')->get('Bride'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Looking For'); ?></label>
                                    </div>
                                </div>

                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <select class="form-control form--control" name="marital_status">
                                            <option value=""><?php echo app('translator')->get('All'); ?></option>
                                            <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maritalStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($maritalStatus->title); ?>" <?php if(request()->marital_status == $maritalStatus->title): echo 'selected'; endif; ?>><?php echo e(__($maritalStatus->title)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Marital Status'); ?></label>
                                    </div>
                                </div>

                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <select class="form-control form--control" name="religion">
                                            <option value=""><?php echo app('translator')->get('All'); ?></option>
                                            <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($religion->name); ?>"><?php echo e(__($religion->name)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Religion'); ?></label>
                                    </div>
                                </div>

                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <select class="form-control form--control" name="country">
                                            <option value=""><?php echo app('translator')->get('All'); ?></option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country); ?>" <?php if($country == request()->country): echo 'selected'; endif; ?>><?php echo e(__($country)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Country'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <input class="form-control form--control" id="profession" name="profession" type="text" value="<?php echo e(request()->profession); ?>">
                                        <label class="form--label" for="profession"><?php echo app('translator')->get('Profession'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <input class="form-control form--control" id="city" name="city" type="text" value="<?php echo e(request()->city); ?>">
                                        <label class="form--label" for="city"><?php echo app('translator')->get('City'); ?></label>
                                    </div>
                                </div>

                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <select class="form-control form--control" name="smoking_status">
                                            <option value=""><?php echo app('translator')->get('All'); ?></option>
                                            <option value="1" <?php if(request()->smoking_status == 1): echo 'selected'; endif; ?>><?php echo app('translator')->get('Smoker'); ?></option>
                                            <option value="0" <?php if(request()->smoking_status == 0): echo 'selected'; endif; ?>><?php echo app('translator')->get('Non-smoker'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Smoking Habits'); ?></label>
                                    </div>
                                </div>

                                <div class="col-sm-12 mt-4">
                                    <div class="input--group">
                                        <select class="form-control form--control" name="drinking_status">
                                            <option value=""><?php echo app('translator')->get('All'); ?></option>
                                            <option value="1" <?php if(request()->drinking_status == 1): echo 'selected'; endif; ?>><?php echo app('translator')->get('Drunker'); ?></option>
                                            <option value="0" <?php if(request()->drinking_status == 0): echo 'selected'; endif; ?>><?php echo app('translator')->get('Non-drunker'); ?></option>
                                        </select>
                                        <label class="form--label"><?php echo app('translator')->get('Drinking Status'); ?></label>
                                    </div>
                                </div>
                            </div>
                            <input name="page" type="hidden">
                        </form>
                    </div>
                </div>
                <div class="col-xl-9 col-md-12">
                    <div class="position-relative">
                        <div class="search-overlay d-none">
                            <div class="search-overlay__inner">
                                <span class="search-overlay__spinner"></span>
                            </div>
                        </div>
                        <div class="search__left-bar mb-xl-0 d-flex justify-content-between mb-3 flex-wrap">
                            <div class="filter-icon d-xl-none d-block">
                                <i class="fas fa-list"></i>
                            </div>
                        </div>
                        <div class="row gy-4 member-wrapper">
                            <?php echo $__env->make($activeTemplate . 'partials.members', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Search Result End -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('report-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b = $component; } ?>
<?php $component = App\View\Components\InterestExpressModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('interest-express-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InterestExpressModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b)): ?>
<?php $component = $__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b; ?>
<?php unset($__componentOriginal55adc14b0c1a5de184a78bc1d8a212248c39f20b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";

            let min = "<?php echo e($height['min']); ?>";
            let max = "<?php echo e($height['max']); ?>";

            let minHeight = parseFloat(min);
            let maxHeight = Math.ceil(parseFloat(max));
            //height range
            $("#slider-range").slider({
                range: true,
                min: minHeight,
                max: maxHeight,

                values: [minHeight, maxHeight],
                slide: function(event, ui) {
                    $("#height").val("" + ui.values[0] + " - " + ui.values[1] + " Ft");
                },
                stop: function(event, ui) {
                    $('.form-search').submit();
                }
            });
            $("#height").val("" + $("#slider-range").slider("values", 0) +
                " - " + $("#slider-range").slider("values", 1) + " Ft");


            // search by ajax
            let form = $('.form-search');
            form.find('.form--control').on('focusout, change', function() {
                form.find('[name=page]').val(0);
                form.submit();
            });

            $(document).on('click', '.pagination .page-link', function(e) {
                e.preventDefault();
                if ($(this).parents('.page-item').hasClass('active')) {
                    return false;
                }

                let page = $(this).attr('href').match(/page=([0-9]+)/)[1];
                form.find('[name=page]').val(page);
                form.submit();
            });

            form.on('submit', function(e) {
                e.preventDefault();
                let data = form.serialize();

                let url = form.attr('action');
                let wrapper = $('.member-wrapper');

                $.ajax({
                    type: "get",
                    url: url,
                    data: data,
                    dataType: "json",
                    beforeSend: function() {
                        $(document).find('.search-overlay').removeClass('d-none');
                    },
                    success: function(response) {
                        if (response.html) {
                            wrapper.html(response.html);
                        }
                    },
                    complete: function() {
                        $(document).find('.search-overlay').addClass('d-none');
                    },
                });

            })

        })(jQuery);
    </script>

    <script>
        "use strict";

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        let config = {
            routes: {
                addShortList: "<?php echo e(route('user.add.short.list')); ?>",
                removeShortList: "<?php echo e(route('user.remove.short.list')); ?>",
            },
            loadingText: {
                addShortList: "<?php echo e(trans('Shortlisting')); ?>",
                removeShortList: "<?php echo e(trans('Removing')); ?>",
                interestExpress: "<?php echo e(trans('Processing')); ?>",
            },
            buttonText: {
                addShortList: "<?php echo e(trans('Shortlist')); ?>",
                removeShortList: "<?php echo e(trans('Shortlisted')); ?>",
                interestExpressed: "<?php echo e(trans('Interested')); ?>",
                expressInterest: "<?php echo e(trans('Interest')); ?>",
            }
        }

        $('.express-interest-form').on('submit', function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            let url = $(this).attr('action');
            let modal = $('#interestExpressModal');
            let id = modal.find('[name=interesting_id]').val();
            let li = $(`.interestExpressBtn[data-interesting_id="${id}"]`).parents('li');
            $.ajax({
                type: "post",
                url: url,
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $(li).find('a').html(`<i class="fas fa-heart"></i>${config.loadingText.interestExpress}..`);
                },
                success: function(response) {
                    modal.modal('hide');
                    if (response.success) {
                        notify('success', response.success);
                        li.find('a').remove();
                        li.html(`<a href="javascript:void(0)" class="base-color">
                            <i class="fas fa-heart"></i>${config.buttonText.interestExpressed}
                        </a>`);
                    } else {
                        notify('error', response.error);
                        li.html(`<a href="javascript:void(0)" class="interestExpressBtn" data-interesting_id="${id}">
                                <i class="fas fa-heart"></i>${config.buttonText.expressInterest}
                        </a>`);
                    }
                }
            });
        })
    </script>
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/member.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/members/list.blade.php ENDPATH**/ ?>