<?php
    $info = json_decode(json_encode(getIpInfo()), true);
    $mobileCode = @implode(',', $info['code']);
    $countries = json_decode(file_get_contents(resource_path('views/partials/country.json')));
    $registerContent = getContent('register.content', true);
    $policyPages = getContent('policy_pages.element', false, null, true);
?>
<?php $__env->startSection('content'); ?>
    <div class="login section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <div class="login__wrapper">
                        <form class="login__form verify-gcaptcha" action="<?php echo e(route('user.register')); ?>" autocomplete="off" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="section__head text-center">
                                <h2 class="login-title mt-0"><?php echo e(__($registerContent->data_values->heading)); ?></h2>
                                <p class="t-short-para mx-auto mb-0 text-center">
                                    <?php echo e(__($registerContent->data_values->subheading)); ?>

                                </p>
                            </div>
                            <div class="row g-3">
                                <div class="col-sm-12">
                                    <div class="input--group">
                                        <select class="form-select form--control form-control" id="looking_for" name="looking_for" required>
                                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                            <option value="1" <?php if(old('looking_for') == 1): echo 'selected'; endif; ?>><?php echo app('translator')->get('Bridegroom'); ?></option>
                                            <option value="2" <?php if(old('looking_for') == 2): echo 'selected'; endif; ?>><?php echo app('translator')->get('Bride'); ?></option>
                                        </select>
                                        <label class="form--label" for="looking_for"><?php echo app('translator')->get('Looking For'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control checkUser" id="username" name="username" type="text" value="<?php echo e(old('username')); ?>" autocomplete="off" placeholder="none" required>
                                        <label class="form--label" for="username"><?php echo app('translator')->get('Username'); ?></label>
                                        <small class="text-danger usernameExist"></small>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" id="firstname" name="firstname" type="text" value="<?php echo e(old('firstname')); ?>" autocomplete="off" placeholder="none" required>
                                        <label class="form--label" for="firstname"><?php echo app('translator')->get('First Name'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control" id="lastname" name="lastname" type="text" value="<?php echo e(old('lastname')); ?>" autocomplete="off" placeholder="none" required>
                                        <label class="form--label" for="lastname"><?php echo app('translator')->get('Last Name'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input--group">
                                        <input class="form-control form--control checkUser" id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" placeholder="none" required>
                                        <label class="form--label" for="email"><?php echo app('translator')->get('E-Mail Address'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6 mt-4">
                                    <div class="input--group">
                                        <select class="form-select form-control form--control" id="country" name="country">
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-code="<?php echo e($key); ?>" data-mobile_code="<?php echo e($country->dial_code); ?>" value="<?php echo e($country->country); ?>" <?php if(old('country') == $key): echo 'selected'; endif; ?>>
                                                    <?php echo e(__($country->country)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="form--label" for="country"><?php echo app('translator')->get('Country'); ?></label>
                                    </div>
                                </div>
                                <div class="col-sm-6 mt-4">
                                    <div class="input--group">
                                        <div class="input-group">
                                            <span class="input-group-text mobile-code"></span>
                                            <input name="mobile_code" type="hidden">
                                            <input name="country_code" type="hidden">
                                            <input class="form-control form--control checkUser" id="mobile" name="mobile" type="number" value="<?php echo e(old('mobile')); ?>" placeholder="none" required>
                                        </div>
                                        <small class="text-danger mobileExist"></small>
                                    </div>
                                </div>
                                <div class="col-sm-6 mt-4">
                                    <div class="input--group">
                                        <input class="form-control form--control" id="password" name="password" type="password" placeholder="none" required>
                                        <label class="form--label" for="password"><?php echo app('translator')->get('Password'); ?></label>
                                        <?php if($general->secure_password): ?>
                                            <div class="input-popup">
                                                <p class="error lower"><?php echo app('translator')->get('1 small letter minimum'); ?></p>
                                                <p class="error capital"><?php echo app('translator')->get('1 capital letter minimum'); ?></p>
                                                <p class="error number"><?php echo app('translator')->get('1 number minimum'); ?></p>
                                                <p class="error special"><?php echo app('translator')->get('1 special character minimum'); ?></p>
                                                <p class="error minimum"><?php echo app('translator')->get('6 character password'); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm-6 mt-4">
                                    <div class="input--group">
                                        <input class="form-control form--control" id="password_confirmation" name="password_confirmation" type="password" placeholder="none" required>
                                        <label class="form--label" for="password_confirmation"><?php echo app('translator')->get('Confirm Password'); ?></label>
                                    </div>
                                </div>

                                <?php if (isset($component)) { $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243 = $component; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Captcha::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243)): ?>
<?php $component = $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243; ?>
<?php unset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243); ?>
<?php endif; ?>

                                <?php if($general->agree): ?>
                                    <div class="col-sm-12 mt-4">
                                        <div class="input--group d-flex align-items-center justify-content-start flex-wrap text-start">
                                            <div class="form--check me-2">
                                                <input class="form-check-input" id="agree" name="agree" type="checkbox" <?php if(old('agree')): echo 'checked'; endif; ?> required>
                                                <label class="form-check-label" for="agree">
                                                    <?php echo app('translator')->get('I agree with '); ?>
                                                </label>
                                                <?php $__currentLoopData = $policyPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('policy.pages', [slug($policy->data_values->title), $policy->id])); ?>" target="_blank">
                                                        <?php echo e(__($policy->data_values->title)); ?>

                                                    </a>
                                                    <?php if(!$loop->last): ?>
                                                        ,
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="col-12">
                                    <button class="btn btn--md btn--base w-100" data-bs-toggle="list" type="submit"> <?php echo app('translator')->get('Register'); ?> </button>
                                </div>

                                <div class="col-sm-12">
                                    <div class="login-account text-center">
                                        <p class="mb-0 mt-3"><?php echo app('translator')->get('Have an account? '); ?> <a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login'); ?></a></p>
                                    </div>
                                </div>

                            </div>
                        </form>
                        <?php echo $__env->make($activeTemplate . 'partials.social_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="existModalCenter" role="dialog" aria-hidden="true" aria-labelledby="existModalCenterTitle" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="existModalLongTitle"><?php echo app('translator')->get('You are with us'); ?></h5>
                    <span class="close" data-bs-dismiss="modal" type="button" aria-label="Close">
                        <i class="las la-times"></i>
                    </span>
                </div>
                <div class="modal-body">
                    <h6><?php echo app('translator')->get('You already have an account, please login!'); ?></h6>
                </div>
                <div class="modal-footer">
                    <button class="btn btn--dark btn-sm" data-bs-dismiss="modal" type="button"><?php echo app('translator')->get('Close'); ?></button>
                    <a class="btn btn--base btn-sm" href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login'); ?></a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php if($general->secure_password): ?>
    <?php $__env->startPush('script-lib'); ?>
        <script src="<?php echo e(asset('assets/global/js/secure_password.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        (function($) {
            <?php if($mobileCode): ?>
                $(`option[data-code=<?php echo e($mobileCode); ?>]`).attr('selected', '');
            <?php endif; ?>

            $('select[name=country]').change(function() {
                $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
                $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
                $('.mobile-code').text('+' + $('select[name=country] :selected').data('mobile_code'));
            });
            $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
            $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
            $('.mobile-code').text('+' + $('select[name=country] :selected').data('mobile_code'));

            $('.checkUser').on('focusout', function(e) {
                var url = '<?php echo e(route('user.checkUser')); ?>';
                var value = $(this).val();
                var token = '<?php echo e(csrf_token()); ?>';
                if ($(this).attr('name') == 'mobile') {
                    var mobile = `${$('.mobile-code').text().substr(1)}${value}`;
                    var data = {
                        mobile: mobile,
                        _token: token
                    }
                }
                if ($(this).attr('name') == 'email') {
                    var data = {
                        email: value,
                        _token: token
                    }
                }
                if ($(this).attr('name') == 'username') {
                    var data = {
                        username: value,
                        _token: token
                    }
                }
                $.post(url, data, function(response) {
                    if (response.data != false && response.type == 'email') {
                        $('#existModalCenter').modal('show');
                    } else if (response.data != false) {
                        $(`.${response.type}Exist`).text(`${response.type} already exist`);
                    } else {
                        $(`.${response.type}Exist`).text('');
                    }
                });
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .country-code .input-group-text {
            background: #fff !important;
        }

        .country-code select {
            border: none;
        }

        .country-code select:focus {
            border: none;
            outline: none;
        }

        .modal .btn {
            padding: 5px 10px !important;
        }

        .modal-title {
            margin: 0;
            line-height: 0 !important;
        }

        .modal-body h6 {
            margin: 1rem 1rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/dcbbd/demo.divorcedcommunity.com/core/resources/views/templates/basic/user/auth/register.blade.php ENDPATH**/ ?>