<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PhysicalAttribute extends Model
{

}
